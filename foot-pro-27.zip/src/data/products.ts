export interface Product {
  id: string;
  name: {
    fr: string;
    ar: string;
  };
  category: string;
  subcategory: string;
  price: number;
  brand: string;
  sizes: string[];
  colors: {
    fr: string[];
    ar: string[];
  };
  image: string;
  description: {
    fr: string;
    ar: string;
  };
  features: {
    fr: string[];
    ar: string[];
  };
  isNew?: boolean;
  isBestSeller?: boolean;
  inStock?: boolean;
  stockCount?: number;
}

export const CATEGORIES = [
  {
    id: "chaussures",
    name: { fr: "CHAUSSURES", ar: "أحذية" },
    subcategories: [
      { id: "crampons", name: { fr: "Soulier (Crampons)", ar: "كراپون (أرضية عشبية)" } },
      { id: "tf", name: { fr: "Tout Terrain TF", ar: "توت تيران TF" } },
      { id: "salle", name: { fr: "Foot Salle", ar: "كرة القدم داخل القاعة" } }
    ]
  },
  {
    id: "maillots",
    name: { fr: "MAILLOTS & TENUES", ar: "أقمصة وأطقم" },
    subcategories: [
      { id: "clubs", name: { fr: "Maillots Clubs", ar: "قمصان أندية" } },
      { id: "nationales", name: { fr: "Maillots Équipes Nationales", ar: "قمصان منتخبات وطنية" } }
    ]
  },
  {
    id: "vetements",
    name: { fr: "VÊTEMENTS SPORT", ar: "ملابس رياضية" },
    subcategories: [
      { id: "survetements", name: { fr: "Survêtements", ar: "بذلات رياضية (Survêtement)" } },
      { id: "fisou", name: { fr: "Fisou", ar: "فيزو (Fisou)" } },
      { id: "cyclistes", name: { fr: "Cyclistes", ar: "سراويل الدراجين" } }
    ]
  },
  {
    id: "accessoires",
    name: { fr: "ACCESSOIRES JOUEUR", ar: "إكسسوارات اللاعب" },
    subcategories: [
      { id: "chaussettes", name: { fr: "Chaussettes", ar: "جوارب رياضية" } },
      { id: "gants", name: { fr: "Gants Gardien", ar: "قفازات حارس المرمى" } },
      { id: "tibias", name: { fr: "Protège Tibias", ar: "واقي الساق" } }
    ]
  },
  {
    id: "equipement",
    name: { fr: "ÉQUIPEMENT", ar: "معدات رياضية" },
    subcategories: [
      { id: "ballons", name: { fr: "Ballons", ar: "كرات قدم" } },
      { id: "sacs", name: { fr: "Sacs Sport", ar: "حقائب رياضية" } },
      { id: "pompes", name: { fr: "Pompes Ballon", ar: "مضخات كرات" } }
    ]
  },
  {
    id: "style",
    name: { fr: "STYLE & EXTRA", ar: "ستايل وإضافات" },
    subcategories: [
      { id: "casquettes", name: { fr: "Casquettes", ar: "قبعات" } },
      { id: "claquettes", name: { fr: "Claquettes", ar: "نعال / سلايدز" } },
      { id: "lifestyle", name: { fr: "Lifestyle Football", ar: "نمط حياة كرة القدم" } }
    ]
  }
];

export const BRANDS = ["Nike", "Adidas", "Puma", "Mizuno", "Umbro", "New Balance", "Reusch"];

export const PRODUCTS: Product[] = [
  {
    id: "nike-mercurial-vapor",
    name: {
      fr: "Nike Mercurial Vapor 15 Elite FG",
      ar: "نايكي ميركوريال فابور 15 إيليت FG"
    },
    category: "chaussures",
    subcategory: "crampons",
    price: 26000,
    brand: "Nike",
    sizes: ["40", "41", "42", "43", "44", "45"],
    colors: {
      fr: ["Neon Jaune", "Noir"],
      ar: ["أصفر فوسفوري", "أسود"]
    },
    image: "/src/assets/images/nike_mercurial_vapor_1780429800398.png",
    description: {
      fr: "La Nike Mercurial Vapor 15 Elite FG est conçue pour la vitesse ultime sur terrain herbeux. Elle est équipée d'une unité Zoom Air 3/4 spécifique au football pour un rebond réactif maximal, et d'une structure Vaporposite+ adhérente pour un contrôle exceptionnel à haute vitesse.",
      ar: "تم تصميم نايكي ميركوريال فابور 15 إيليت FG للسرعة القصوى على الملاعب العشبية. مجهزة بوحدة Zoom Air بمقدار 3/4 مخصصة لكرة القدم للاستجابة السريعة، وبنية Vaporposite+ اللاصقة لتحكم استثنائي بالكرة تحت السرعات العالية."
    },
    features: {
      fr: [
        "Unité Zoom Air 3/4 intégrée sous la plaque pour une sensation de rebond dynamique",
        "Empeigne Vaporposite+ combinant un mesh grillagé adhérent et une doublure premium",
        "Crampons Tri-Star offrant une adhérence multidirectionnelle à chaque pas",
        "Conception ultra-légère optimisée pour la vitesse pure",
        "Produit original importé"
      ],
      ar: [
        "وحدة Zoom Air بمقدار 3/4 مدمجة تحت النعل لشعور ديناميكي بالارتداد",
        "جزء علوي بقنية Vaporposite+ يجمع بين شبك لاصق وبطانة ممتازة",
        "سدادات كراپون Tri-Star توفر تماسكاً متعدد الاتجاهات في كل خطوة",
        "تصميم خفيف الوزن للغاية ومحسن للسرعة الخالصة",
        "منتج أصلي مستورد"
      ]
    },
    isBestSeller: true,
    isNew: true
  },
  {
    id: "adidas-predator-elite",
    name: {
      fr: "Adidas Predator Elite FG",
      ar: "أديداس بريداتور إيليت FG"
    },
    category: "chaussures",
    subcategory: "crampons",
    price: 27500,
    brand: "Adidas",
    sizes: ["39", "40", "41", "42", "43", "44"],
    colors: {
      fr: ["Noir Noir", "Blanc", "Rouge Solaire"],
      ar: ["أسود فخم", "أبيض", "أحمر ناري"]
    },
    image: "/src/assets/images/adidas_predator_elite_1780429816424.png",
    description: {
      fr: "La reine absolue du contrôle. La Adidas Predator Elite est dotée d'éléments d'adhérence Strikeskin en caoutchouc positionnés de manière stratégique sur la zone de frappe, couplés à une languette emblématique repliable pour une précision clinique.",
      ar: "الملكة المطلقة للتحكم بالكرة. تتميز أديداس بريداتور إيليت بعناصر Strikeskin المطاطية الموزعة بدقة في مناطق التسديد، مع لسان الحذاء الكلاسيكي القابل للطي لدقة متناهية تشبه الجراحة."
    },
    features: {
      fr: [
        "Ailette Strikeskin en caoutchouc pour un grip et des effets de balle parfaits",
        "Tige HybridTouch 2.0 souple offrant un confort seconde peau",
        "Semelle extérieure Controlframe 2.0 garantissant une stabilité maximale",
        "Languette repliable classique avec bande élastique",
        "Importé d'Europe, qualité professionnelle garantie"
      ],
      ar: [
        "شفرات Strikeskin المطاطية لثبات مذهل وتأثير دوران مثالي للكرة",
        "جزء علوي HybridTouch 2.0 مرن يوفر راحة كأنها طبقة جلد ثانية",
        "نعل خارجي Controlframe 2.0 يضمن استقراراً أقصى على العشب",
        "اللسان المطوي الكلاسيكي للحذاء مع شريط مطاطي كلاسيكي",
        "مستورد من أوروبا بضمان الجودة الاحترافية"
      ]
    },
    isBestSeller: true
  },
  {
    id: "puma-future-ultimate",
    name: {
      fr: "Puma Future Ultimate TF",
      ar: "بوما فيوتشر أولتيميت TF"
    },
    category: "chaussures",
    subcategory: "tf",
    price: 18500,
    brand: "Puma",
    sizes: ["40", "41", "42", "43", "44"],
    colors: {
      fr: ["Bleu Pro", "Blanc"],
      ar: ["أزرق احترافي", "أبيض"]
    },
    image: "/src/assets/images/puma_future_ultimate_1780429829911.png",
    description: {
      fr: "Inspirée par le style de jeu créatif de Neymar Jr. La Puma Future Ultimate TF intègre une tige FUZIONFIT360 avec double mesh, un soutien PWRTAPE pour un maintien personnalisé et un ajustement parfait, idéal pour les terrains synthétiques.",
      ar: "مستوحاة من أسلوب اللعب الإبداعي للنجم نيمار جونيور. تم تجهيز بوما فيوتشر أولتيميت TF بجزء علوي FUZIONFIT360 مع شبكة مزدوجة ودعم شريط PWRTAPE للتماسك المخصص والملاءمة المثالية لملاعب الترتان."
    },
    features: {
      fr: [
        "Tige FUZIONFIT360 adaptative combinant double mesh et tricot extensible",
        "Technologie PWRTAPE ciblée pour le soutien et la durabilité lors des changements de direction",
        "Semelle en caoutchouc multi-crampons de profil bas pour terrains synthétiques durs",
        "Textures de contact 3D aux zones clés pour un contrôle de balle supérieur"
      ],
      ar: [
        "جزء علوي FUZIONFIT360 متكيف يجمع بين شبكة مزدوجة ونسيج مرن",
        "تقنية شريط PWRTAPE الموجهة للدعم والمتانة القصوى أثناء المراوغة",
        "نعل مطاطي منخفض ببروزات متعددة للأراضي والتر تان الاصطناعي",
        "بروزات بارزة ثلاثية الأبعاد 3D في المناطق الأساسية لتحكم فائق بالكرة"
      ]
    },
    isNew: true
  },
  {
    id: "real-madrid-jersey",
    name: {
      fr: "Maillot Officiel Real Madrid 2026/2027",
      ar: "قميص ريال مدريد الرسمي 2026/2027"
    },
    category: "maillots",
    subcategory: "clubs",
    price: 7500,
    brand: "Adidas",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: {
      fr: ["Blanc", "Or"],
      ar: ["أبيض ملكي", "ذهبي"]
    },
    image: "/src/assets/images/real_madrid_jersey_1780429844103.png",
    description: {
      fr: "Représentez l'histoire et la gloire européenne du Real Madrid. Ce maillot officiel présente un design blanc royal épuré rehaussé de détails dorés de prestige, fabriqué avec la technologie respirante AEROREADY d'Adidas pour un confort inégalé.",
      ar: "ارتدِ تاريخ المجد الأوروبي لريال مدريد. يتميز قميص النادي الملكي الرسمي بلون أبيض ناصع مع تفاصيل ذهبية فاخرة، وصُنعت بتقنية AEROREADY الفائقة من أديداس للتهوية والراحة الاستثنائية."
    },
    features: {
      fr: [
        "Technologie AEROREADY qui évacue la transpiration pour vous garder au sec",
        "Blason du Real Madrid brodé avec précision sur la poitrine",
        "Col stylé de haute qualité avec coupe sportive confortable",
        "Détails dorés qui célèbrent le statut de légende du club"
      ],
      ar: [
        "تقنية AEROREADY الطاردة للرطوبة والعرق للحفاظ على جفاف جسدك",
        "شعار نادي ريال مدريد مطرز بدقة احترافية عالية ثلاثية الأبعاد على الصدر",
        "ياقة أنيقة وعالية الجودة بتصميم رياضي يتناسب مع الحركة",
        "خصائص ذهبية أنيقة تحتفل بالمستويات التاريخية للنادي"
      ]
    },
    isNew: true,
    isBestSeller: true
  },
  {
    id: "algeria-jersey",
    name: {
      fr: "Maillot Algérie FAF Édition Spéciale",
      ar: "قميص المنتخب الوطني الجزائري - إصدار خاص"
    },
    category: "maillots",
    subcategory: "nationales",
    price: 8000,
    brand: "Adidas",
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: {
      fr: ["Vert", "Or", "Blanc"],
      ar: ["أخضر فخر", "ذهبي", "أبيض"]
    },
    image: "/src/assets/images/algeria_jersey_1780429859934.png",
    description: {
      fr: "Portez fièrement les couleurs des Fennecs d'Algérie avec ce maillot au design authentique inspiré du patrimoine algérien historique. Tissu premium respirant développé pour le confort des joueurs et des supporters passionnés.",
      ar: "احمل ألوان محاربي الصحراء بفخر مع هذا القميص ذو التصميم الأصيل المستوحى من التراث الجزائري العريق. نسيج ممتاز فائق التهوية مطور لتوفير الراحة التامة للاعبين والمشجعين الأوفياء."
    },
    features: {
      fr: [
        "Écusson FAF officiel thermocollé de haute durabilité",
        "Motifs artistiques traditionnels élégants incrustés dans le tissu",
        "Maille aérée sous les bras pour une régulation thermique optimale",
        "Coupe athlétique ajustée garantissant une excellente liberté de mouvement"
      ],
      ar: [
        "شعار الاتحادية الجزائرية لكرة القدم FAF رسمي ومتين للغاية",
        "زخارف فنية تراثية أنيقة مدمجة بجمالية رائعة في النسيج",
        "شبكة تهوية تحت الإبطين للتنظيم الحراري المثالي للجسم",
        "قصة رياضية رائعة تضمن حرية الحركة المريحة"
      ]
    },
    isBestSeller: true
  },
  {
    id: "nike-elite-socks",
    name: {
      fr: "Chaussettes Antidérapantes Nike Grip Elite",
      ar: "جوارب نايكي جريب إيليت المضادة للانزلاق"
    },
    category: "accessoires",
    subcategory: "chaussettes",
    price: 1800,
    brand: "Nike",
    sizes: ["Taille Unique (39-45)"],
    colors: {
      fr: ["Blanc", "Noir"],
      ar: ["أبيض", "أسود"]
    },
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80",
    description: {
      fr: "Les chaussettes antidérapantes Nike Elite Grip préviennent le glissement du pied à l'intérieur du crampon, améliorant de manière critique la réactivité, le confort et protégeant contre les ampoules.",
      ar: "جوارب نايكي إليت جريب المضادة للانزلاق تمنع انزلاق القدم تماماً داخل الحذاء، مما يحسن الاستجابة عند الدوران والسرعة، ويحمي بشكل ممتاز من تقرحات القدم."
    },
    features: {
      fr: [
        "Pads antidérapants en silicone de haute qualité sous le pied",
        "Tissu respirant avec système d'évacuation de la transpiration",
        "Zones élastiques au niveau de la cheville et de la voûte plantaire pour un maintien accru"
      ],
      ar: [
        "وسادات سيليكون عالية الجودة مانعة للانزلاق تحت كعب ومشط القدم",
        "نسيج فائق التهوية يسمح بمرور الهواء وتصريف رطوبة العرق",
        "مناطق تمدد مرنة عند الكاحل وقوس القدم لتأمين الثبات والاستقرار"
      ]
    }
  },
  {
    id: "reusch-attrakt-gloves",
    name: {
      fr: "Gants Gardien Reusch Attrakt Gold X",
      ar: "قفازات حارس المرمى رويش أتراكت جولد X"
    },
    category: "accessoires",
    subcategory: "gants",
    price: 14500,
    brand: "Reusch",
    sizes: ["8", "9", "10"],
    colors: {
      fr: ["Bleu Cyan", "Orange"],
      ar: ["أزرق سماوي", "برتقالي"]
    },
    image: "https://images.unsplash.com/photo-1516567727245-ad8c68f3ec93?auto=format&fit=crop&w=600&q=80",
    description: {
      fr: "Le choix des professionnels. Les gants Reusch Attrakt Gold X disposent du latex allemand Gold X de niveau élite pour un grip extraordinaire sur ballons secs et humides.",
      ar: "خيار المحترفين الأول. تتميز قفازات رويش أتراكت جولد X بلاصق اللاتكس الألماني Gold X من الفئة النخبوية لتأمين إمساك أسطوري بالكرة في الطقس الجاف والرطب."
    },
    features: {
      fr: [
        "Latex allemand de niveau supérieur Gold X pour une adhérence inégalée",
        "Coupe Evolution Negative Cut offrant un ajustement optimal et une surface d'arrêt maximale",
        "Zone d'impact en mousse de silicone renforcée pour dégager avec puissance"
      ],
      ar: [
        "لاتكس ألماني فاخر Gold X لالتصاق غير مسبوق في جميع الظروف الجوية",
        "قصة Evolution Negative توفر ملاءمة حقيقية ومساحة تسديد ممتازة",
        "منطقة لكم الكرة معززة بالسيليكون المرن لدفع الكرة بقوة وأمان"
      ]
    }
  },
  {
    id: "adidas-ucl-matchball",
    name: {
      fr: "Ballon de Match Officiel UEFA Champions League",
      ar: "كرة المباريات الرسمية لدوري أبطال أوروبا"
    },
    category: "equipement",
    subcategory: "ballons",
    price: 19000,
    brand: "Adidas",
    sizes: ["5"],
    colors: {
      fr: ["Multi-couleurs"],
      ar: ["متعدد الألوان"]
    },
    image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=600&q=80",
    description: {
      fr: "Jouez avec le ballon de la plus grande compétition de clubs au monde. Ce ballon adidas UCL Pro présente une surface texturée sans couture thermocollée pour une trajectoire prévisible et un faible rebond d'eau.",
      ar: "العب بكرة أكبر وأعرق بطولة أندية في العالم. تتميز هذه الكرة الرسمية UCL Pro من أديداس بسطح حراري سلس بدون خياطة لتأمين مسار طيران دقيق للغاية وامتصاص صفري للمياه."
    },
    features: {
      fr: [
        "Certification FIFA Quality Pro pour des performances d'élite",
        "Surface texturée premium sans couture reliée thermiquement",
        "Hautement résistant avec une vessie en butyle haut de gamme"
      ],
      ar: [
        "شهادة الجودة الاحترافية من الفيفا FIFA Quality Pro لأداء مذهل",
        "سطح خارجي محكم وبدون طبقات ملحوم حرارياً لتوازن حقيقي",
        "مقاومة ممتازة للتلف مع كيس هواء داخلي من البوتيل لحفظ الضغط"
      ]
    },
    isNew: true
  }
];

export const TRANSLATIONS = {
  fr: {
    storeName: "Foot Pro 27",
    tagline: "Le Magasin de Football Premium",
    location: "Massra, Mostaganem, Algérie",
    locationShort: "Massra, Mostaganem",
    searchPlaceholder: "Rechercher un produit (marque, modèle...)",
    allProducts: "Tous les Produits",
    home: "Accueil",
    about: "À Propos",
    contact: "Contact",
    faq: "FAQ",
    privacy: "Confidentialité",
    categories: "Catégories",
    filterBy: "Filtrer Par",
    sortBy: "Trier Par",
    size: "Taille / المقاس",
    color: "Couleur",
    price: "Prix",
    brand: "Marque",
    all: "Tout",
    noProducts: "Aucun produit ne correspond à ces critères.",
    commanderWhatsApp: "Commander sur WhatsApp",
    deliveryTitle: "Livraison Rapide",
    deliveryLocal: "Livraison locale et à domicile dans les 58 wilayas d'Algérie. Expédition internationale possible.",
    bestSellers: "Meilleures Ventes",
    newArrivals: "Nouveautés",
    exclusiveSelection: "Une sélection exclusive des meilleurs équipements originaux pour les vrais passionnés de football.",
    orderStepsTitle: "Comment commander ?",
    orderStep1: "Choisissez votre modèle, taille et couleur.",
    orderStep2: "Cliquez sur commander pour générer le message WhatsApp.",
    orderStep3: "Nous confirmons la disponibilité et expédions dans les plus brefs délais !",
    whyUsTitle: "Pourquoi Foot Pro 27 ?",
    whyUs1Title: "100% Original & Importé",
    whyUs1Desc: "Nous garantissons la qualité authentique importée directement d'Europe.",
    whyUs2Title: "Livraison sur 58 Wilayas",
    whyUs2Desc: "Paiement sécurisé ou à la livraison selon votre wilaya.",
    whyUs3Title: "Service Client WhatsApp 24/7",
    whyUs3Desc: "Une équipe à l'écoute pour vous conseiller sur la taille et le modèle parfait.",
    aboutHeading: "Qui Sommes-Nous ?",
    aboutIntro: "Foot Pro 27 est le temple du football à Massra, Mostaganem, et à travers toute l'Algérie. Spécialisé dans l'importation d'équipements sportifs haut de gamme, originaux et professionnels, nous équipons les joueurs de tous niveaux avec le meilleur matériel disponible sur le marché mondial.",
    aboutDescription: "Que vous cherchiez la dernière paire de crampons des professionnels (Nike Mercurial, Adidas Predator, Puma Future), les maillots officiels des plus grands clubs et équipes nationales, ou des accessoires indispensables au joueur de football, Foot Pro 27 est votre partenaire de confiance. Authentique, sans concession sur la qualité, nous assurons une livraison rapide et un service à l'écoute.",
    contactHeading: "Contactez-Nous",
    contactIntro: "Besoin d'un conseil ? Envie de commander ou de visitez notre magasin ? Contactez notre équipe via ces différents canaux.",
    contactPhone: "Téléphone",
    contactAddress: "Adresse Physique",
    faqHeading: "Foire Aux Questions (FAQ)",
    faq1Q: "Les produits sont-ils originaux ?",
    faq1A: "Oui, absolument. Chez Foot Pro 27, nous nous spécialisons uniquement dans les produits originaux importés directement de distributeurs agréés en Europe. Aucune contrefaçon chez nous !",
    faq2Q: "Comment se déroule la livraison ?",
    faq2A: "La livraison est effectuée via nos partenaires de livraison sur l'ensemble des 58 wilayas d'Algérie. Les délais varient entre 24h et 72h selon votre emplacement.",
    faq3Q: "Comment puis-je payer ma commande ?",
    faq3A: "Nous acceptons le paiement en espèces à la livraison (selon la wilaya), ou virement CCP/Baridimob avant l'expédition.",
    faq4Q: "Puis-je changer la taille si elle ne convient pas ?",
    faq4A: "Oui, les échanges de taille sont possibles dans les 48 heures suivant la réception du colis, sous réserve que le produit n'ait pas été utilisé et soit dans son emballage d'origine. Les frais de retour demeurent à la charge de l'acheteur.",
    privacyHeading: "Politique de Confidentialité",
    privacyText: "Chez Foot Pro 27, nous accordons une importance primordiale à votre vie privée. Les données collectées via notre site sont uniquement utilisées pour faciliter le traitement et la livraison de vos commandes via WhatsApp. Nous ne partageons ni ne revendons vos informations à des tiers. Vos communications avec nous sont totalement sécurisées.",
    viewDetails: "Voir Détails",
    backToStore: "Retour à la boutique",
    allRightsReserved: "Tous droits réservés.",
    currency: "DA",
    filterCategory: "Catégorie",
    filterSubcategory: "Sous-catégorie",
    filterBrand: "Marque",
    filterSize: "Taille",
    filterColor: "Couleur",
    filterPriceMax: "Prix Max",
    priceRange: "Fourchette de prix :",
    searchResult: "Résultat(s) trouvé(s)",
    featuredCategories: "Nos Catégories",
    whatsappFloatingTooltip: "Besoin d'aide ? Écrivez-nous !",
    featuredProducts: "Sélection Vedette"
  },
  ar: {
    storeName: "فوت برو 27",
    tagline: "متجر كرة القدم الممتاز والأصلي",
    location: "ماسرى، مستغانم، الجزائر",
    locationShort: "ماسرى، مستغانم",
    searchPlaceholder: "ابحث عن منتج (ماركة، موديل...)",
    allProducts: "كل المنتجات",
    home: "الرئيسية",
    about: "من نحن",
    contact: "اتصل بنا",
    faq: "الأسئلة الشائعة",
    privacy: "سياسة الخصوصية",
    categories: "الفئات",
    filterBy: "تصفية حسب",
    sortBy: "ترتيب حسب",
    size: "المقاس",
    color: "اللون",
    price: "السعر",
    brand: "العلامة التجارية",
    all: "الكل",
    noProducts: "لا توجد منتجات تطابق هذه المعايير.",
    commanderWhatsApp: "الطلب عبر واتساب",
    deliveryTitle: "توصيل سريع وموثوق",
    deliveryLocal: "توصيل محلي وإلى المنزل لجميع الولايات الـ 58 في الجزائر. متوفر أيضاً شحن دولي.",
    bestSellers: "الأكثر مبيعاً",
    newArrivals: "وصلنا حديثاً",
    exclusiveSelection: "تشكيلة حصرية من أفضل المستلزمات والأحذية الأصلية لعشاق ولاعبي كرة القدم الحقيقيين.",
    orderStepsTitle: "كيف تقوم بالطلب؟",
    orderStep1: "اختر الموديل، المقاس، واللون المناسب لك.",
    orderStep2: "اضغط على زر 'الطلب عبر واتساب' لتوليد رسالة طلب تلقائية ومكتملة البيانات.",
    orderStep3: "سنقوم بتأكيد توفر المنتج وتجهيز طلبيتك لشحنها لك فوراً!",
    whyUsTitle: "لماذا فوت برو 27؟",
    whyUs1Title: "100% أصلي ومستورد",
    whyUs1Desc: "نحن نضمن لك جودة حقيقية مستوردة مباشرة من أوروبا لضمان الأداء الأفضل.",
    whyUs2Title: "توصيل لكافة الولايات الـ 58",
    whyUs2Desc: "ادفع عند الاستلام بآمان أو من خلال طرق الدفع المتاحة وسهلة الاستخدام.",
    whyUs3Title: "دعم عبر واتساب 24/7",
    whyUs3Desc: "فريقنا متواجد دائماً لمساعدتك في اختيار المقاس المناسب والموديل الأفضل لك.",
    aboutHeading: "من نحن؟",
    aboutIntro: "متجر فوت برو 27 هو محراب كرة القدم في ماسرى، مستغانم، وعبر كامل التراب الوطني بالجزائر. متخصصون في استيراد وتوفير المعدات الرياضية الفاخرة، الاحترافية والأصلية لتمكين اللاعبين والرياضيين من بلوغ أقصى إمكانياتهم باستخدام أفضل المستلزمات الرياضية في العالم.",
    aboutDescription: "سواء كنت تبحث عن أحدث إصدارات الأحذية الرياضية للمحترفين (مثل نايكي ميركوريال، أديداس بريديتور، بوما فيوتشر) أو قمصان الأقمصة الرسمية لأقوى وأعرق الأندية والمنتخبات العالمية، أو الملحقات الأساسية للاعبين، فإن فوت برو 27 هو شريكك الرياضي الموثوق. جودة أصلية خاضعة لأعلى المعايير، مع ضمان شحن سريع وتجربة زبون مثالية.",
    contactHeading: "اتصل بنا",
    contactIntro: "هل تحتاج المساعدة أو ترغب بالاستفسار عن مقاسك أو الطلب مباشرة؟ تواصل مع فريقنا الاحترافي عبر القنوات المتعددة التالية.",
    contactPhone: "الهاتف",
    contactAddress: "موقع المحل",
    faqHeading: "الأسئلة الشائعة (FAQ)",
    faq1Q: "هل منتجاتكم أصلية بالفعل؟",
    faq1A: "نعم، بكل تأكيد. نحن في فوت برو 27 لا نتعامل نهائياً بالنسخ المقلدة أو الرديئة. جميع بضائعنا أصلية 100% ويتم استيرادها مباشرة من الموزعين المعتمدين في الدول الأوروبية لتقديم الضمان الكامل للعميل.",
    faq2Q: "كيف تتم عملية التوصيل والمدة؟",
    faq2A: "يتم الشحن مع أفضل شركات التوصيل السريع إلى غاية باب منزلك أو النقطة الأقرب إليك في جميع ولايات الجزائر الـ 58. يتراوح وقت التسليم عادة بين 24 إلى 72 ساعة كأقصى حد.",
    faq3Q: "ما هي طرق الدفع المتاحة لديكم؟",
    faq3A: "نوفر الدفع نقداً عند استلام الطرد الخاص بك (حسب الولاية)، كما نتيح الدفع المسبق السهل والسريع عبر الحساب البريدي الجاري CCP أو من خلال تطبيق Baridimob.",
    faq4Q: "هل يمكنني استبدال المقاس إذا لم يناسبني؟",
    faq4A: "نعم، الاستبدال متاح ومرحب به خلال 48 ساعة فقط من استلامك للطلب، بشرط عدم استخدام المنتج نهائياً وأن يظل في حالته الجديدة تماماً وداخل علبته الأصلية غير المتضررة. يتحمل الزبون تكاليف الشحن الخاصة بالإرجاع والتبديل.",
    privacyHeading: "سياسة الخصوصية",
    privacyText: "نحن في فوت برو 27 نضع حماية خصوصيتك وسريتك في أقصى اهتماماتنا. كافة البيانات التي تقدمها لتسهيل التوصيل أو تزويدنا بها من خلال طلبات واتساب تبقى آمنة ومحفوظة تماماً. لن يتم دمجها أو تسريبها أو بيعها لأي جهة ثالثة مطلقاً.",
    viewDetails: "عرض التفاصيل",
    backToStore: "العودة للمتجر",
    allRightsReserved: "جميع الحقوق محفوظة.",
    currency: "د.ج",
    filterCategory: "الفئة",
    filterSubcategory: "الفئة الفرعية",
    filterBrand: "العلامة التجارية",
    filterSize: "المقاس",
    filterColor: "اللون",
    filterPriceMax: "أقصى سعر",
    priceRange: "نطاق السعر:",
    searchResult: "من النتائج المطابقة",
    featuredCategories: "تصنيفاتنا المميزة",
    whatsappFloatingTooltip: "تحتاج لمساعدة؟ راسلنا الآن!",
    featuredProducts: "المنتجات المميزة"
  }
};
