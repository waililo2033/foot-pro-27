import React, { useState, useEffect } from "react";
import { 
  Lock, 
  Unlock, 
  Trash2, 
  Edit3, 
  Plus, 
  X, 
  Save, 
  Upload, 
  CheckCircle, 
  XCircle,
  AlertTriangle,
  Image as ImageIcon, 
  ArrowLeft, 
  Award, 
  Sparkles, 
  ShoppingBag,
  Settings,
  Database,
  CloudLightning,
  ChevronDown,
  Mail,
  Sliders,
  Copy,
  Info
} from "lucide-react";
import { Product, CATEGORIES } from "../data/products";
import { 
  isSupabaseConfigured, 
  getSupabaseClient, 
  getSupabaseConfig, 
  saveSupabaseConfig, 
  clearSupabaseConfig, 
  saveProductToDb, 
  deleteProductFromDb, 
  batchSyncProducts, 
  fetchProductsFromDb,
  SUPABASE_SQL_CREATION 
} from "../lib/supabase";
import { compressImage } from "../utils/imageCompressor";

interface AdminDashboardProps {
  lang: "fr" | "ar";
  productsList: Product[];
  setProductsList: (newList: Product[]) => void;
}

export default function AdminDashboard({ lang, productsList, setProductsList }: AdminDashboardProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  // Auth states
  const [email, setEmail] = useState("Footpromostaganem@gmail.com");
  const [password, setPassword] = useState("");
  const [fallbackPasscode, setFallbackPasscode] = useState("");
  const [isSupabaseAuth, setIsSupabaseAuth] = useState(false);
  const [authError, setAuthError] = useState("");
  const [authLoading, setAuthLoading] = useState(false);

  // Settings & DB setup values
  const [isDbConfigOpen, setIsDbConfigOpen] = useState(false);
  const [supabaseUrlInput, setSupabaseUrlInput] = useState("");
  const [supabaseAnonKeyInput, setSupabaseAnonKeyInput] = useState("");
  const [isCopied, setIsCopied] = useState(false);
  const [syncLoading, setSyncLoading] = useState(false);
  const [syncMessage, setSyncMessage] = useState("");

  // Product Form state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  
  // Form input states
  const [id, setId] = useState("");
  const [nameFr, setNameFr] = useState("");
  const [nameAr, setNameAr] = useState("");
  const [descriptionFr, setDescriptionFr] = useState("");
  const [descriptionAr, setDescriptionAr] = useState("");
  const [category, setCategory] = useState("chaussures");
  const [subcategory, setSubcategory] = useState("");
  const [price, setPrice] = useState<number>(8500);
  const [brand, setBrand] = useState("Nike");
  const [sizes, setSizes] = useState<string[]>([]);
  const [colorsFr, setColorsFr] = useState<string[]>([]);
  const [colorsAr, setColorsAr] = useState<string[]>([]);
  const [image, setImage] = useState("");
  const [isNew, setIsNew] = useState(true);
  const [isBestSeller, setIsBestSeller] = useState(false);
  const [featuresFr, setFeaturesFr] = useState<string[]>([]);
  const [featuresAr, setFeaturesAr] = useState<string[]>([]);
  
  // New Stock properties
  const [inStock, setInStock] = useState<boolean>(true);
  const [stockCount, setStockCount] = useState<number>(5);

  // Helpers tags inputs with phone-optimized inputs
  const [tempColorFr, setTempColorFr] = useState("");
  const [tempColorAr, setTempColorAr] = useState("");
  const [tempFeatureFr, setTempFeatureFr] = useState("");
  const [tempFeatureAr, setTempFeatureAr] = useState("");
  
  // Compression loading state
  const [imageCompresingLoading, setImageCompressingLoading] = useState(false);

  const isConfigured = isSupabaseConfigured();

  // Load active connection credentials to local inputs
  useEffect(() => {
    const config = getSupabaseConfig();
    if (config) {
      setSupabaseUrlInput(config.url);
      setSupabaseAnonKeyInput(config.anonKey);
      setIsSupabaseAuth(true);
    }
  }, []);

  // Handle Authentication (Supabase Auth vs Fallback Passcode)
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthLoading(true);

    if (isSupabaseAuth && isConfigured) {
      // Direct Supabase Authentication
      const supabase = getSupabaseClient();
      if (!supabase) {
        setAuthError("Supabase standard client error. Please check your credentials.");
        setAuthLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: "Footpromostaganem@gmail.com",
          password: password,
        });

        if (error) {
          setAuthError(lang === "fr" 
            ? `Échec de connexion : ${error.message}` 
            : `خطأ في تسجيل الدخول: ${error.message}`);
        } else if (data.session) {
          setIsAuthenticated(true);
          // Try to fetch latest products instantly to reflect from Supabase
          const liveData = await fetchProductsFromDb();
          if (liveData && liveData.length > 0) {
            setProductsList(liveData);
          }
        }
      } catch (err: any) {
        setAuthError(err.message || "Authentication exception.");
      } finally {
        setAuthLoading(false);
      }
    } else {
      // Local Fallback Passcode login (e.g. for initial bootstrap, or testing locally)
      setAuthLoading(false);
      if (fallbackPasscode === "footpro27") {
        setIsAuthenticated(true);
        setAuthError("");
      } else {
        setAuthError(lang === "fr" 
          ? "Code d'accès administrateur incorrect." 
          : "الرمز السري المساعد غير صحيح.");
      }
    }
  };

  // Safe Supabase credentials storage setting action
  const handleSaveDbConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabaseUrlInput || !supabaseAnonKeyInput) {
      alert("Veuillez entrer l'URL et la clé anonyme.");
      return;
    }
    
    try {
      saveSupabaseConfig(supabaseUrlInput.trim(), supabaseAnonKeyInput.trim());
      setIsSupabaseAuth(true);
      alert(lang === "fr" 
        ? "Connexion Supabase configurée avec succès !" 
        : "تم حفظ إعدادات سوبابيس بنجاح !");
      setIsDbConfigOpen(false);
      
      // Attempt live sync pull instantly after saved
      const freshProducts = await fetchProductsFromDb();
      if (freshProducts && freshProducts.length > 0) {
        setProductsList(freshProducts);
      }
    } catch (err: any) {
      alert(`Erreur de connexion : ${err.message}`);
    }
  };

  // Database credential clearing
  const handleClearDbConfig = () => {
    const doubleCheck = window.confirm(
      lang === "fr" 
        ? "Voulez-vous réinitialiser et déconnecter Supabase ?" 
        : "هل تود حذف إعدادات سوبابيس والرجوع للحفظ المحلي المساعد ؟"
    );
    if (doubleCheck) {
      clearSupabaseConfig();
      setSupabaseUrlInput("");
      setSupabaseAnonKeyInput("");
      setIsSupabaseAuth(false);
      alert(lang === "fr" ? "Supabase déconnecté." : "تم فصل سوبابيس.");
    }
  };

  // Transfer client product data list into Supabase with 1-click
  const handleSyncToCloud = async () => {
    if (!isConfigured) {
      alert(lang === "fr" 
        ? "Veuillez d'abord configurer vos clés Supabase !" 
        : "يرجى ملء مفاتيح الاتصال أولاً !");
      return;
    }

    const verify = window.confirm(
      lang === "fr"
        ? `Êtes-vous certain de vouloir copier ${productsList.length} articles vers votre base de données Supabase ?`
        : `هل أنت متأكد من رغبتك في نقل وتأمين ${productsList.length} منتج مخزن حالياً إلى قاعدة سوبابيس ؟`
    );

    if (!verify) return;

    setSyncLoading(true);
    setSyncMessage(lang === "fr" ? "Synchronisation en cours..." : "جاري الرفع للحضانة السحابية...");

    try {
      const response = await batchSyncProducts(productsList);
      if (response.success) {
        setSyncMessage(lang === "fr" 
          ? `Succès ! ${response.count} produits copiés sur Supabase.` 
          : `تم بنجاح ! تم نقل ${response.count} منتج إلى سوبابيس.`);
        
        // Refresh products list state from cloud DB
        const fresh = await fetchProductsFromDb();
        if (fresh) setProductsList(fresh);
      } else {
        setSyncMessage(`Erreur de transfert : ${response.error || "Inconnu"}`);
      }
    } catch (err: any) {
      setSyncMessage(`Erreur de connexion : ${err.message}`);
    } finally {
      setSyncLoading(false);
    }
  };

  // Open Create Mode Form (optimized initialized fields for rapid thumb-taps)
  const handleOpenCreate = () => {
    setEditingProduct(null);
    setId("prod-" + Math.floor(1000 + Math.random() * 9000).toString());
    setNameFr("");
    setNameAr("");
    setDescriptionFr("");
    setDescriptionAr("");
    setCategory("chaussures");
    setSubcategory("crampons");
    setPrice(9500);
    setBrand("Nike");
    setSizes(["40", "41", "42", "43", "44", "45"]);
    setColorsFr(["Blanc", "Bleu"]);
    setColorsAr(["أبيض", "أزرق"]);
    setImage("");
    setIsNew(true);
    setIsBestSeller(false);
    setInStock(true);
    setStockCount(12);
    setFeaturesFr(["Emballage d'origine inclus", "Crampons solides et certifiés", "Produit Elite de qualité"]);
    setFeaturesAr(["العلبة وحقيبة الجزمة ملحقة", "أرضية صلبة ومثبتة", "جودة أصلية ممتازة"]);
    
    // Clear temp values
    setTempColorFr("");
    setTempColorAr("");
    setTempFeatureFr("");
    setTempFeatureAr("");
    
    setIsFormOpen(true);
  };

  // Open Edit Mode Form
  const handleOpenEdit = (product: Product) => {
    setEditingProduct(product);
    setId(product.id);
    setNameFr(product.name.fr);
    setNameAr(product.name.ar);
    setDescriptionFr(product.description.fr);
    setDescriptionAr(product.description.ar);
    setCategory(product.category);
    setSubcategory(product.subcategory);
    setPrice(product.price);
    setBrand(product.brand);
    setSizes(product.sizes);
    setColorsFr(product.colors.fr);
    setColorsAr(product.colors.ar);
    setImage(product.image);
    setIsNew(product.isNew ?? false);
    setIsBestSeller(product.isBestSeller ?? false);
    setInStock(product.inStock !== false); // Default to true if undefined
    setStockCount(product.stockCount !== undefined ? product.stockCount : 8);
    setFeaturesFr(product.features.fr);
    setFeaturesAr(product.features.ar);
    
    setTempColorFr("");
    setTempColorAr("");
    setTempFeatureFr("");
    setTempFeatureAr("");
    
    setIsFormOpen(true);
  };

  // Delete product row with instant local and DB updates
  const handleDelete = async (productId: string) => {
    const isConfirm = window.confirm(
      lang === "fr" 
        ? "Êtes-vous certain de vouloir supprimer définitivement ce produit ?" 
        : "هل أنت متأكد من رغبتك في حذف هذا المنتج نهائياً من المتجر ؟"
    );
    if (!isConfirm) return;

    // Fast local UI update (optimistic response)
    const updated = productsList.filter((p) => p.id !== productId);
    setProductsList(updated);

    // Save to backend if connected
    if (isConfigured) {
      try {
        await deleteProductFromDb(productId);
      } catch (err) {
        console.error("Failed to delete from Supabase Database:", err);
      }
    }
  };

  // Smartphone gallery direct image upload with high-quality Canvas compression
  const handleImageFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageCompressingLoading(true);
      try {
        // Compress down dynamically to max width 900px, quality 0.75
        const base64Compressed = await compressImage(file, 900, 0.75);
        setImage(base64Compressed);
      } catch (err) {
        console.error("Canvas compression failed, falling back to FileReader:", err);
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === "string") {
            setImage(reader.result);
          }
        };
        reader.readAsDataURL(file);
      } finally {
        setImageCompressingLoading(false);
      }
    }
  };

  // Save changes locally and to Supabase
  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameFr || !nameAr || !price) {
      alert(lang === "fr" ? "Veuillez remplir le nom et le prix." : "يرجى كتابة الاسم والسعر للسلعة.");
      return;
    }

    const savedProduct: Product = {
      id,
      name: { fr: nameFr.trim(), ar: nameAr.trim() },
      description: { fr: descriptionFr.trim(), ar: descriptionAr.trim() },
      category,
      subcategory,
      price: Number(price),
      brand,
      sizes,
      colors: { fr: colorsFr, ar: colorsAr },
      image: image || "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format",
      isNew,
      isBestSeller,
      inStock,
      stockCount: Number(stockCount),
      features: { fr: featuresFr, ar: featuresAr }
    };

    // Fast UI state update
    let updated: Product[];
    if (editingProduct) {
      updated = productsList.map((p) => (p.id === editingProduct.id ? savedProduct : p));
    } else {
      updated = [savedProduct, ...productsList];
    }
    setProductsList(updated);

    // Persist to Supabase Database
    if (isConfigured) {
      try {
        const dbResult = await saveProductToDb(savedProduct);
        if (!dbResult) {
          alert("Alerte: Enregistré localement mais échec de connexion Supabase. Vérifiez votre table SQL.");
        }
      } catch (err: any) {
        alert(`Échec d'enregistrement cloud : ${err.message}`);
      }
    }

    setIsFormOpen(false);
  };

  // Interactive addition of colors and descriptors optimized for cell screens
  const addColorFr = () => {
    if (tempColorFr.trim() && !colorsFr.includes(tempColorFr.trim())) {
      setColorsFr([...colorsFr, tempColorFr.trim()]);
      setTempColorFr("");
    }
  };

  const addColorAr = () => {
    if (tempColorAr.trim() && !colorsAr.includes(tempColorAr.trim())) {
      setColorsAr([...colorsAr, tempColorAr.trim()]);
      setTempColorAr("");
    }
  };

  const addFeatureFr = () => {
    if (tempFeatureFr.trim() && !featuresFr.includes(tempFeatureFr.trim())) {
      setFeaturesFr([...featuresFr, tempFeatureFr.trim()]);
      setTempFeatureFr("");
    }
  };

  const addFeatureAr = () => {
    if (tempFeatureAr.trim() && !featuresAr.includes(tempFeatureAr.trim())) {
      setFeaturesAr([...featuresAr, tempFeatureAr.trim()]);
      setTempFeatureAr("");
    }
  };

  const toggleSize = (sz: string) => {
    if (sizes.includes(sz)) {
      setSizes(sizes.filter((s) => s !== sz));
    } else {
      setSizes([...sizes, sz]);
    }
  };

  const copySQLCode = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_CREATION);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Quick statistics counters
  const totalProducts = productsList.length;
  const outOfStockCount = productsList.filter((p) => p.inStock === false || p.stockCount === 0).length;
  const lowStockCount = productsList.filter((p) => p.stockCount !== undefined && p.stockCount > 0 && p.stockCount <= 3).length;
  const inStockCount = totalProducts - outOfStockCount;

  // View 1: Premium Mobile-First Login Shield screen
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-6 sm:my-16 px-4 select-none">
        {/* Toggle option display */}
        <div className="bg-[#0f172a] rounded-3xl border border-white/5 p-6 space-y-6 shadow-2xl relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff510a]/5 blur-2xl rounded-full"></div>
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-[#0071d1]/5 blur-2xl rounded-full"></div>

          {/* Logo and Greeting */}
          <div className="text-center space-y-3">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#ff510a] to-[#0071d1] p-0.5 mx-auto shadow-lg shadow-orange-950/20">
              <div className="w-full h-full bg-[#0f172a] rounded-[14px] flex items-center justify-center text-white">
                <ShoppingBag className="w-7 h-7 text-[#ff510a]" />
              </div>
            </div>
            
            <div className="space-y-1">
              <h1 className="text-xl sm:text-2xl font-black text-white uppercase tracking-tight">
                Foot Pro 27 - Control Panel
              </h1>
              <p className="text-xs text-white/50 font-semibold font-mono tracking-wide uppercase">
                {isConfigured ? "🛡️ MODE SUPABASE CLOUD ACTIF" : "⚡ MODE STOCKAGE INTERNE LOCAL"}
              </p>
            </div>
          </div>

          {/* Connection selection tabs for smartphones */}
          <div className="grid grid-cols-2 gap-1.5 p-1 bg-black/40 rounded-xl border border-white/5">
            <button
              onClick={() => setIsSupabaseAuth(false)}
              className={`py-2.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                !isSupabaseAuth 
                  ? "bg-white/5 text-[#ff510a]" 
                  : "text-white/40 hover:text-white"
              }`}
            >
              Passcode Local
            </button>
            <button
              onClick={() => {
                if (!isConfigured) {
                  alert(lang === "fr" 
                    ? "Supabase n'est pas encore configuré ! Configurez-le ci-dessous." 
                    : "يرجى ملء وصلات سوبابيس أولاً لمعادلة الحساب بالأسفل !");
                  return;
                }
                setIsSupabaseAuth(true);
              }}
              className={`py-2.5 rounded-lg text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
                isSupabaseAuth 
                  ? "bg-white/5 text-[#0071d1]" 
                  : "text-white/40 hover:text-white"
              }`}
            >
              Supabase Auth
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            
            {isSupabaseAuth ? (
              <div className="space-y-3 text-left">
                <div>
                  <label className="text-[10px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Email de l'Administrateur *
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-3 w-4 h-4 text-white/30" />
                    <input
                      type="email"
                      value={email}
                      disabled
                      placeholder="Footpromostaganem@gmail.com"
                      className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-xs font-bold text-white/50"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Mot de passe Supabase *
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-3 w-4 h-4 text-white/30" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Saisissez votre mot de passe..."
                      required
                      className="w-full bg-black/40 border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-xs font-bold text-white focus:outline-none focus:border-[#0071d1] transition-all"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-mono font-bold text-white/40 block uppercase mb-1">
                  Code Secret d'Accès Rapide *
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3 w-4 h-4 text-white/30" />
                  <input
                    type="password"
                    placeholder="Code Secret Admin"
                    value={fallbackPasscode}
                    onChange={(e) => setFallbackPasscode(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-10 pr-4 text-center tracking-widest text-base font-bold text-white focus:outline-none focus:border-[#ff510a] transition-all"
                  />
                </div>
              </div>
            )}

            {authError && (
              <div className="text-[10px] text-red-500 font-bold bg-red-950/20 p-2.5 rounded-xl border border-red-500/10 uppercase tracking-wide leading-relaxed">
                ⚠️ {authError}
              </div>
            )}

            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-4 rounded-xl bg-[#ff510a] hover:bg-[#0071d1] text-white font-black text-xs uppercase tracking-widest transition-all cursor-pointer shadow-md disabled:opacity-50"
            >
              {authLoading ? "PROCES-EN COURS..." : (lang === "fr" ? "Accéder au Panel" : "دخول للوحة التحكم")}
            </button>
          </form>

          {/* Quick instructions indicator for local trials */}
          {!isSupabaseAuth && (
            <p className="text-[9px] text-white/30 font-semibold leading-relaxed">
              👉 {lang === "fr" ? "Indice de démonstration rapide : " : "الرمز السريع للتجربة والمراجعة : "} <span className="font-mono font-black text-white bg-white/5 px-2 py-0.5 rounded ml-0.5">footpro27</span>
            </p>
          )}
        </div>

        {/* Database parameters setup directly from the phone screen */}
        <div className="mt-4 bg-[#0f172a] rounded-3xl border border-white/5 p-5 space-y-4 shadow-xl">
          <button
            onClick={() => setIsDbConfigOpen(!isDbConfigOpen)}
            className="w-full flex items-center justify-between font-black uppercase text-xs text-white/85 cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Database className="w-4 h-4 text-[#0071d1]" />
              {lang === "fr" ? "Configuration Supabase" : "وصلات سوبابيس (إعداد سحابي)"}
            </span>
            <ChevronDown className={`w-4 h-4 text-white/40 transition-transform ${isDbConfigOpen ? "rotate-180" : ""}`} />
          </button>

          {isDbConfigOpen && (
            <div className="space-y-4 text-left border-t border-white/5 pt-4 animate-in slide-in-from-top duration-300">
              
              <div className="p-3 bg-blue-950/10 border border-blue-500/10 rounded-xl space-y-1.5 font-semibold text-[10px] text-blue-400">
                <span className="font-black uppercase flex items-center gap-1">
                  <CloudLightning className="w-3.5 h-3.5 text-blue-400" />
                  Base de données autonome
                </span>
                <p>Enregistrez vos identifiants direct Supabase pour sauvegarder automatiquement vos articles dans le Cloud.</p>
              </div>

              <form onSubmit={handleSaveDbConfig} className="space-y-3">
                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Supabase Project URL
                  </label>
                  <input
                    type="text"
                    value={supabaseUrlInput}
                    onChange={(e) => setSupabaseUrlInput(e.target.value)}
                    placeholder="https://your-project-id.supabase.co"
                    required
                    className="w-full bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Supabase Anon Public API Key
                  </label>
                  <input
                    type="password"
                    value={supabaseAnonKeyInput}
                    onChange={(e) => setSupabaseAnonKeyInput(e.target.value)}
                    placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                    required
                    className="w-full bg-black/40 border border-white/10 rounded-lg py-2 px-3 text-xs text-white font-mono"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="submit"
                    className="flex-grow py-2.5 bg-[#0071d1] hover:bg-white hover:text-black rounded-lg text-[10px] font-black uppercase text-white cursor-pointer transition-colors text-center"
                  >
                    Vérifier & Sauvegarder
                  </button>
                  {isConfigured && (
                    <button
                      type="button"
                      onClick={handleClearDbConfig}
                      className="px-3 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded-lg text-xs transition-colors cursor-pointer"
                    >
                      ×
                    </button>
                  )}
                </div>
              </form>

              {/* Database generator guide */}
              <div className="border-t border-white/5 pt-4 space-y-2">
                <span className="text-[9px] font-mono font-bold text-white/50 block uppercase">
                  Script de Table SQL Supabase
                </span>
                <p className="text-[10px] text-white/40 font-semibold leading-relaxed">
                  Copiez le code SQL ci-dessous avec le bouton et collez-le dans le SQL Editor de Supabase pour créer la table automatiquement :
                </p>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={copySQLCode}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-white/5 border border-white/10 rounded-md text-[9px] font-black text-white hover:text-[#0071d1] cursor-pointer transition-colors"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {isCopied ? "Copié !" : "Copier le Script SQL"}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }

  // View 2: Highly Optimized Mobile-First Control Board Dashboard
  return (
    <div className="max-w-7xl mx-auto px-2 sm:px-6 py-6 space-y-6 animate-in fade-in duration-300">
      
      {/* HEADER SECTION FOR SMARTPHONES */}
      <div className="bg-[#0f172a] rounded-3xl border border-white/5 p-5 flex flex-col gap-4 select-none">
        <div className="flex justify-between items-start gap-2">
          <div className="space-y-1 text-left">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-500 text-[9px] font-black uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Admin connecté
            </span>
            <h1 className="text-xl sm:text-3xl font-black text-white uppercase tracking-tight leading-tight">
              {lang === "fr" ? "Gérer mon magasin" : "التحكم في المتجر"}
            </h1>
            <p className="text-white/40 text-[10px] font-medium truncate max-w-[220px] sm:max-w-none">
              Footpromostaganem@gmail.com
            </p>
          </div>

          <button
            onClick={() => setIsAuthenticated(false)}
            className="px-3 py-2 bg-white/5 hover:bg-red-500/10 border border-white/10 hover:border-red-500/20 hover:text-red-500 rounded-xl text-[10px] font-black uppercase text-white/80 cursor-pointer"
          >
            Déconnexion
          </button>
        </div>

        {/* Action button bar with large smartphone-friendly triggers */}
        <div className="grid grid-cols-2 gap-2 mt-2">
          <button
            onClick={handleOpenCreate}
            className="py-4 rounded-xl bg-[#ff510a] hover:bg-orange-600 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-lg active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            {lang === "fr" ? "Ajouter Produit" : "إضافة منتج"}
          </button>
          
          <button
            onClick={handleSyncToCloud}
            disabled={syncLoading}
            className="py-4 rounded-xl bg-[#0071d1] hover:bg-blue-600 text-white font-black text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer shadow-lg active:scale-95 transition-all disabled:opacity-50"
          >
            <CloudLightning className="w-4 h-4" />
            {syncLoading ? "SYNC..." : (lang === "fr" ? "Sync Supabase" : "تأمين السحابة")}
          </button>
        </div>

        {/* Sync message if present */}
        {syncMessage && (
          <div className="p-3 bg-white/5 border border-white/10 rounded-xl text-center text-[10px] text-white/70 italic font-medium leading-normal animate-pulse">
            ℹ️ {syncMessage}
          </div>
        )}
      </div>

      {/* METRICS ROW optimized with high-contrast text and simple spacing */}
      <div className="grid grid-cols-3 gap-2">
        <div className="p-3 bg-[#0f172a] rounded-2xl border border-white/5 text-center">
          <span className="text-[10px] text-white/40 block font-normal uppercase tracking-wider">PRODUITS</span>
          <span className="text-xl font-bold text-white font-mono mt-0.5 block">{totalProducts}</span>
        </div>
        <div className="p-3 bg-[#0f172a] rounded-2xl border border-white/5 text-center">
          <span className="text-[10px] text-emerald-400 block font-normal uppercase tracking-wider">DISPONIBLE</span>
          <span className="text-xl font-bold text-emerald-400 font-mono mt-0.5 block">{inStockCount}</span>
        </div>
        <div className="p-3 bg-[#0f172a] rounded-2xl border border-white/5 text-center">
          <span className="text-[10px] text-red-400 block font-normal uppercase tracking-wider">RUPTURES</span>
          <span className="text-xl font-bold text-red-400 font-mono mt-0.5 block">{outOfStockCount}</span>
        </div>
      </div>

      {/* MOBILE LIST ITEMS */}
      <div className="space-y-3 text-left">
        <h2 className="text-xs font-black uppercase text-white/40 tracking-widest pl-2">
          {lang === "fr" ? `Catalogue des produits (${totalProducts})` : `قائمة السلع والقطع المعروضة (${totalProducts})`}
        </h2>

        <div className="space-y-2">
          {productsList.map((product) => {
            const hasStock = product.inStock !== false && (product.stockCount === undefined || product.stockCount > 0);
            const qty = product.stockCount !== undefined ? product.stockCount : 0;
            
            return (
              <div 
                key={product.id} 
                className="p-3 bg-[#0f172a] border border-white/5 rounded-2xl flex items-center justify-between gap-3 shadow-md hover:border-white/10"
              >
                {/* Information Block Left */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-xl bg-black/40 overflow-hidden border border-white/10 flex-shrink-0 relative">
                    <img
                      src={product.image}
                      alt={product.name[lang]}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                    {!hasStock && (
                      <span className="absolute inset-0 bg-red-950/80 flex items-center justify-center text-[7px] text-red-400 font-black uppercase text-center select-none tracking-tight">
                        Épuisé
                      </span>
                    )}
                  </div>

                  <div className="min-w-0 space-y-0.5 text-left">
                    <div className="flex items-center gap-1 flex-wrap">
                      <span className="text-[8px] font-mono bg-[#0071d1]/20 text-[#0071d1] font-black uppercase px-1.5 py-0.5 rounded-sm">
                        {product.brand}
                      </span>
                      <span className="text-[8px] font-mono bg-white/5 text-white/45 uppercase px-1.5 py-0.5 rounded-sm">
                        {product.category}
                      </span>
                    </div>

                    <h3 className="text-xs sm:text-sm font-black text-white uppercase truncate max-w-[150px] sm:max-w-xs leading-tight">
                      {product.name[lang]}
                    </h3>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#ff510a] font-mono">
                        {product.price.toLocaleString()} DA
                      </span>
                      
                      {/* Stock Badge dynamic */}
                      {product.inStock === false || qty === 0 ? (
                        <span className="text-[8px] font-bold text-red-500 uppercase">
                          • Rupture
                        </span>
                      ) : qty <= 3 ? (
                        <span className="text-[8px] font-bold text-orange-500 uppercase">
                          • {qty} Restants
                        </span>
                      ) : (
                        <span className="text-[8px] font-bold text-emerald-500 uppercase">
                          • {qty} en Stock
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Tactical Double Buttons Actions with high touch priority */}
                <div className="flex items-center gap-1.5 flex-shrink-0 select-none">
                  <button
                    onClick={() => handleOpenEdit(product)}
                    className="p-3 bg-white/5 border border-white/10 text-white hover:text-[#0071d1] hover:border-[#0071d1] rounded-xl flex items-center justify-center cursor-pointer transition-all active:scale-90"
                    title="Modifier"
                  >
                    <Edit3 className="w-4 h-4 text-[#0071d1]" />
                  </button>
                  
                  <button
                    onClick={() => handleDelete(product.id)}
                    className="p-3 bg-white/5 border border-white/10 text-white hover:text-red-500 hover:border-red-500 rounded-xl flex items-center justify-center cursor-pointer transition-all active:scale-90"
                    title="Supprimer"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SMARTPHONE DIALOG PORTRAIT MODAL */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/80 backdrop-blur-xs flex items-end sm:items-center justify-center p-3">
          <div className="bg-[#0f172a] border border-white/10 rounded-t-3xl sm:rounded-3xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-5 sm:p-7 space-y-5 shadow-2xl relative text-left">
            
            {/* Form Top Title */}
            <div className="flex justify-between items-center border-b border-white/5 pb-3 select-none">
              <h2 className="text-base font-black text-white uppercase tracking-tight flex items-center gap-2">
                <Sliders className="w-4.5 h-4.5 text-[#ff510a]" />
                {editingProduct 
                  ? (lang === "fr" ? "Modifier Produit" : "تعديل حانات السلعة") 
                  : (lang === "fr" ? "Créer Produit" : "إنشاء مواصفات السلعة")}
              </h2>
              <button
                onClick={() => setIsFormOpen(false)}
                className="w-8 h-8 rounded-full bg-white/5 hover:bg-red-500 hover:text-white flex items-center justify-center text-white/50 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Editor form sheets */}
            <form onSubmit={handleSave} className="space-y-4">
              
              {/* BRAND AND ID UNIQUE */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Marque / Brand *
                  </label>
                  <select
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white uppercase font-black"
                  >
                    <option value="Nike">Nike</option>
                    <option value="Adidas">Adidas</option>
                    <option value="Puma">Puma</option>
                    <option value="Mizuno">Mizuno</option>
                    <option value="Umbro">Umbro</option>
                    <option value="New Balance">New Balance</option>
                    <option value="Reusch">Reusch</option>
                    <option value="Autres Marques">Autres Marques</option>
                  </select>
                </div>

                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    ID de Référence *
                  </label>
                  <input
                    type="text"
                    disabled
                    value={id}
                    className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white/50 font-mono font-bold uppercase"
                  />
                </div>
              </div>

              {/* NAME FIELDS IN FRENCH AND ARABIC */}
              <div className="space-y-3">
                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Nom de l'article (Français) *
                  </label>
                  <input
                    type="text"
                    value={nameFr}
                    onChange={(e) => setNameFr(e.target.value)}
                    placeholder="e.g. Nike Tiempo Legend Elite"
                    required
                    className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white font-bold"
                  />
                </div>
                
                <div>
                  <div className="text-right">
                    <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                      اسم السلعة (العربية) *
                    </label>
                    <input
                      type="text"
                      dir="rtl"
                      value={nameAr}
                      onChange={(e) => setNameAr(e.target.value)}
                      placeholder="مثال: نايكي تيمبو ليجند"
                      required
                      className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white font-bold text-right"
                    />
                  </div>
                </div>
              </div>

              {/* CATEGORIES SELECTION & PRICE */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Catégorie Principale
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white font-black"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name.fr}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Prix de vente (DA) *
                  </label>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    min="100"
                    placeholder="24000"
                    required
                    className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white font-mono font-black"
                  />
                </div>
              </div>

              {/* SUBCATEGORIES FOR RAPID FILTERING */}
              <div>
                <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                  Sous-catégorie ou Type
                </label>
                <input
                  type="text"
                  value={subcategory}
                  onChange={(e) => setSubcategory(e.target.value)}
                  placeholder="e.g. crampons, clubs, Survêtements, sacs"
                  className="w-full bg-black/40 border border-white/15 rounded-xl py-2.5 px-3 text-xs text-white font-bold"
                />
              </div>

              {/* STOCK MANAGEMENT PANEL */}
              <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 space-y-3 font-semibold">
                <span className="text-[9px] font-mono font-bold text-[#ff510a] block uppercase">
                  📦 ENREGISTREMENT ET GESTION DU STOCK (QUANTITÉ)
                </span>

                <div className="grid grid-cols-2 gap-3 items-center">
                  {/* Stock Checkbox status */}
                  <label className="flex items-center gap-2 cursor-pointer py-1.5 select-none touch-auto">
                    <input
                      type="checkbox"
                      checked={inStock}
                      onChange={(e) => setInStock(e.target.checked)}
                      className="w-4 h-4 rounded text-[#ff510a] focus:ring-0 bg-black/60 cursor-pointer"
                    />
                    <span className="text-xs text-white text-left">Disponible à la Vente</span>
                  </label>

                  {/* Quantity Input */}
                  <div>
                    <label className="text-[8px] font-mono font-bold text-white/40 block uppercase mb-1">
                      Quantité physique restante (Stock)
                    </label>
                    <input
                      type="number"
                      value={stockCount}
                      onChange={(e) => setStockCount(Number(e.target.value))}
                      min="0"
                      className="w-full bg-black/50 border border-white/10 rounded-xl py-1.5 px-3 text-xs text-white font-mono font-black"
                    />
                  </div>
                </div>
              </div>

              {/* IMAGE DIRECT GALLERY SMARTPHONE COMPRESSOR */}
              <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 space-y-3 select-none">
                <span className="text-[9px] font-mono font-bold text-[#0071d1] block uppercase">
                  🖼️ PHOTO DU PRODUIT DEPUIS LA GALERIE PHOTO
                </span>

                <div className="flex flex-col sm:flex-row gap-3 items-center">
                  
                  {/* Photo Thumbnail */}
                  <div className="w-16 h-16 rounded-xl bg-[#0f172a] border border-white/15 flex items-center justify-center overflow-hidden flex-shrink-0 relative">
                    {image ? (
                      <img src={image} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <ImageIcon className="w-6 h-6 text-white/30" />
                    )}
                    {imageCompresingLoading && (
                      <div className="absolute inset-0 bg-black/75 flex items-center justify-center text-[7px] text-white/80 font-black uppercase text-center">
                        Compresse...
                      </div>
                    )}
                  </div>

                  <div className="flex-grow w-full space-y-1.5 text-left">
                    <div className="flex items-center gap-2">
                      <label className="flex items-center gap-1.5 px-4 py-3 bg-[#0071d1] hover:bg-white hover:text-black rounded-xl text-[9px] font-black uppercase tracking-wider text-white cursor-pointer shadow-md select-none">
                        <Upload className="w-4 h-4" />
                        Choisir une Photo de la Galerie
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleImageFileChange}
                          className="hidden"
                        />
                      </label>
                      {image && (
                        <button
                          type="button"
                          onClick={() => setImage("")}
                          className="text-[9px] font-bold text-red-500 uppercase hover:underline cursor-pointer"
                        >
                          Effacer
                        </button>
                      )}
                    </div>

                    <input
                      type="text"
                      value={image}
                      onChange={(e) => setImage(e.target.value)}
                      placeholder="Ou coller une URL d'image externe..."
                      className="w-full bg-black/40 border border-white/10 rounded-lg py-1.5 px-2 text-[10px] text-white/80"
                    />
                  </div>
                </div>
              </div>

              {/* FOOTBALL SIZES SELECTION BUTTONS BLOCK */}
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono font-bold text-white/40 block uppercase">
                  Tailles / Pointures disponibles (Taper à activer/désactiver)
                </label>
                <div className="flex flex-wrap gap-1 bg-black/20 p-2 rounded-xl border border-white/5 select-none">
                  {["39", "40", "41", "41.5", "42", "42.5", "43", "44", "44.5", "45", "46", "S", "M", "L", "XL", "XXL", "Uni"].map((sz) => {
                    const active = sizes.includes(sz);
                    return (
                      <button
                        type="button"
                        key={sz}
                        onClick={() => toggleSize(sz)}
                        className={`px-3 py-2 rounded-lg text-xs font-black transition-all cursor-pointer ${
                          active
                            ? "bg-[#ff510a] text-white shadow-sm"
                            : "bg-black/40 text-white/40 border border-white/5"
                        }`}
                      >
                        {sz}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* TECHNICAL DESCRIPTIONS */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1">
                    Description technique (Français)
                  </label>
                  <textarea
                    rows={2}
                    value={descriptionFr}
                    onChange={(e) => setDescriptionFr(e.target.value)}
                    placeholder="Finition haut de gamme, tige structurée, etc."
                    className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white font-semibold leading-normal"
                  />
                </div>
                <div className="text-right">
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase mb-1 text-right">
                    التفاصيل والمواصفات (العربية)
                  </label>
                  <textarea
                    rows={2}
                    dir="rtl"
                    value={descriptionAr}
                    onChange={(e) => setDescriptionAr(e.target.value)}
                    placeholder="جزمة أصلية ممتازة، كعب مبطن لحماية الكاحل..."
                    className="w-full bg-black/40 border border-white/15 rounded-xl py-2 px-3 text-xs text-white font-semibold leading-normal text-right"
                  />
                </div>
              </div>

              {/* COLORS SECTOR WITH ADD BUTTONS FOR THUMB TYPING */}
              <div className="grid grid-cols-2 gap-3 font-semibold text-[10px]">
                
                {/* French Colors */}
                <div className="space-y-2 bg-black/10 p-2.5 rounded-xl border border-white/5 text-left">
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase">
                    Couleurs (Français)
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={tempColorFr}
                      onChange={(e) => setTempColorFr(e.target.value)}
                      placeholder="e.g. Noir brillant"
                      className="flex-grow bg-black/40 border border-white/10 rounded-lg py-1.5 px-2 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={addColorFr}
                      className="px-2.5 bg-white/5 border border-white/10 text-white rounded-lg text-xs font-black cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {colorsFr.map((c) => (
                      <span key={c} className="bg-white/5 border border-white/10 text-[9px] font-bold px-2 py-0.5 rounded flex items-center gap-1">
                        {c}
                        <button type="button" onClick={() => setColorsFr(colorsFr.filter((cf) => cf !== c))} className="text-red-500 font-bold ml-1">×</button>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Arabic Colors */}
                <div className="space-y-2 bg-black/10 p-2.5 rounded-xl border border-white/5 text-right">
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase">
                    الألوان (العربية)
                  </label>
                  <div className="flex gap-1.5" dir="rtl">
                    <input
                      type="text"
                      dir="rtl"
                      value={tempColorAr}
                      onChange={(e) => setTempColorAr(e.target.value)}
                      placeholder="مثال: أسود فاقع"
                      className="flex-grow bg-black/40 border border-white/10 rounded-lg py-1.5 px-2 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={addColorAr}
                      className="px-2.5 bg-white/5 border border-white/10 text-white rounded-lg text-xs font-black cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1 justify-end" dir="rtl">
                    {colorsAr.map((c) => (
                      <span key={c} className="bg-white/5 border border-white/10 text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1">
                        {c}
                        <button type="button" onClick={() => setColorsAr(colorsAr.filter((cf) => cf !== c))} className="text-red-500 font-bold mr-1">×</button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* FEATURES ITEMS BULLETS */}
              <div className="grid grid-cols-2 gap-3 text-[10px] font-semibold">
                
                {/* French Features */}
                <div className="space-y-2 bg-black/10 p-2.5 rounded-xl border border-white/5 text-left">
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase">
                    Avantages (Français)
                  </label>
                  <div className="flex gap-1.5">
                    <input
                      type="text"
                      value={tempFeatureFr}
                      onChange={(e) => setTempFeatureFr(e.target.value)}
                      placeholder="e.g. Sac fourni"
                      className="flex-grow bg-black/40 border border-white/10 rounded-lg py-1.5 px-2 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={addFeatureFr}
                      className="px-2.5 bg-white/5 border border-white/10 text-white rounded-lg text-xs font-black cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                  <div className="flex flex-col gap-1">
                    {featuresFr.map((f, index) => (
                      <span key={index} className="text-[9px] text-white/60 flex items-center justify-between bg-black/15 p-1 rounded">
                        • {f}
                        <button type="button" onClick={() => setFeaturesFr(featuresFr.filter((_, fi) => fi !== index))} className="text-red-500 font-bold ml-1">×</button>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Arabic Features */}
                <div className="space-y-2 bg-black/10 p-2.5 rounded-xl border border-white/5 text-right">
                  <label className="text-[9px] font-mono font-bold text-white/40 block uppercase">
                    مميزات السلعة (العربية)
                  </label>
                  <div className="flex gap-1.5" dir="rtl">
                    <input
                      type="text"
                      dir="rtl"
                      value={tempFeatureAr}
                      onChange={(e) => setTempFeatureAr(e.target.value)}
                      placeholder="مثال: حقيبة ملحقة"
                      className="flex-grow bg-black/40 border border-white/10 rounded-lg py-1.5 px-2 text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={addFeatureAr}
                      className="px-2.5 bg-white/5 border border-white/10 text-white rounded-lg text-xs font-black cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                  <div className="flex flex-col gap-1" dir="rtl">
                    {featuresAr.map((f, index) => (
                      <span key={index} className="text-[9px] text-white/60 flex items-center justify-between bg-black/15 p-1 rounded">
                        • {f}
                        <button type="button" onClick={() => setFeaturesAr(featuresAr.filter((_, fi) => fi !== index))} className="text-red-500 font-bold mr-1">×</button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* BEST SELLERS & NEW FLAGS */}
              <div className="flex items-center gap-4 bg-black/10 p-3 rounded-xl border border-white/5 select-none font-black text-[11px] select-none justify-center">
                <label className="flex items-center gap-2 cursor-pointer text-white">
                  <input
                    type="checkbox"
                    checked={isNew}
                    onChange={(e) => setIsNew(e.target.checked)}
                    className="w-4 h-4 rounded text-[#0071d1] focus:ring-0 bg-black/60 cursor-pointer"
                  />
                  <span>🌟 Nouveauté</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-white">
                  <input
                    type="checkbox"
                    checked={isBestSeller}
                    onChange={(e) => setIsBestSeller(e.target.checked)}
                    className="w-4 h-4 rounded text-[#ff510a] focus:ring-0 bg-black/60 cursor-pointer"
                  />
                  <span>🔥 Best Seller</span>
                </label>
              </div>

              {/* SAVE / DISMISS TRIGGER ROW FOR PHONE THUMBS */}
              <div className="flex flex-col gap-2 pt-3 border-t border-white/5 select-none">
                <button
                  type="submit"
                  disabled={imageCompresingLoading}
                  className="w-full inline-flex items-center justify-center gap-2 bg-[#ff510a] hover:bg-white hover:text-black py-4 rounded-xl text-xs font-black uppercase tracking-wider text-white transition-all cursor-pointer shadow-md"
                >
                  <Save className="w-4.5 h-4.5" />
                  {lang === "fr" ? "Enregistrer sur mon Catalogue" : "حفظ في الكتالوج"}
                </button>
                
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="w-full py-3.5 bg-white/5 border border-white/10 hover:bg-white/15 rounded-xl text-xs font-black uppercase text-white transition-all cursor-pointer text-center"
                >
                  {lang === "fr" ? "Annuler et Retourner" : "إلغاء وتراجع"}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
}
