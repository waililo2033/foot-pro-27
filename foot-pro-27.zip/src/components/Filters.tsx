import { SlidersHorizontal, RotateCcw } from "lucide-react";
import { CATEGORIES, BRANDS, TRANSLATIONS } from "../data/products";

interface FiltersProps {
  lang: "fr" | "ar";
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  selectedSubcategory: string;
  setSelectedSubcategory: (subcat: string) => void;
  selectedBrand: string;
  setSelectedBrand: (brand: string) => void;
  selectedSize: string;
  setSelectedSize: (size: string) => void;
  selectedColor: string;
  setSelectedColor: (color: string) => void;
  maxPrice: number;
  setMaxPrice: (price: number) => void;
  onClearFilters: () => void;
}

export default function Filters({
  lang,
  selectedCategory,
  setSelectedCategory,
  selectedSubcategory,
  setSelectedSubcategory,
  selectedBrand,
  setSelectedBrand,
  selectedSize,
  setSelectedSize,
  selectedColor,
  setSelectedColor,
  maxPrice,
  setMaxPrice,
  onClearFilters,
}: FiltersProps) {
  const t = TRANSLATIONS[lang];

  // List of unified sizes
  const sizesList = ["39", "40", "41", "42", "43", "44", "45", "S", "M", "L", "XL", "XXL"];

  // Colors list translated optionally, but keeping basic ones matching mock keys
  const colorsList = lang === "fr" 
    ? ["Blanc", "Noir", "Neon Jaune", "Or", "Vert", "Bleu Pro", "Bleu Cyan", "Orange", "Multi-couleurs"]
    : ["أبيض", "أسود", "أصفر فوسفوري", "ذهبي", "أخضر", "أزرق", "برتقالي", "متعدد الألوان"];

  // Find subcategories belonging to selected category
  const activeCategoryObj = CATEGORIES.find((c) => c.id === selectedCategory);
  const subcategories = activeCategoryObj ? activeCategoryObj.subcategories : [];

  return (
    <div className="bg-[#0f172a] border border-white/5 p-5 rounded-2xl space-y-6 text-left sticky top-24 shadow-2xl select-none">
      
      {/* Filters Title Header */}
      <div className="flex justify-between items-center pb-4 border-b border-white/10">
        <h3 className="text-xs font-black tracking-widest text-white inline-flex items-center gap-2 font-mono uppercase">
          <SlidersHorizontal className="w-4 h-4 text-[#0071d1]" />
          {t.filterBy}
        </h3>
        <button
          id="btn-clear-filters"
          onClick={onClearFilters}
          className="text-xs font-black text-white/40 hover:text-[#ff510a] tracking-widest uppercase inline-flex items-center gap-1 cursor-pointer transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          {lang === "fr" ? "Réinitialiser" : "إعادة ضبط"}
        </button>
      </div>

      {/* CATEGORY SELECTOR */}
      <div className="space-y-2.5">
        <label className="text-[10px] font-black text-white/40 tracking-widest uppercase block">
          {t.filterCategory} / الفئة
        </label>
        <div className="flex flex-col gap-1.5">
          <button
            onClick={() => {
              setSelectedCategory("");
              setSelectedSubcategory("");
            }}
            className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
              selectedCategory === ""
                ? "bg-[#0071d1] text-white shadow-md shadow-blue-900/40"
                : "bg-black/30 text-white/60 border border-white/5 hover:text-white hover:bg-white/5"
            }`}
          >
            {t.all} ({lang === "fr" ? "Toutes les catégories" : "كل الفئات"})
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id);
                setSelectedSubcategory("");
              }}
              className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                selectedCategory === cat.id
                  ? "bg-[#0071d1] text-white shadow-md shadow-blue-900/40"
                  : "bg-black/30 text-white/60 border border-white/5 hover:text-white hover:bg-white/5"
              }`}
            >
              {cat.name[lang]}
            </button>
          ))}
        </div>
      </div>

      {/* SUBCATEGORY SELECTOR (ONLY SHOW IF CATEGORY SELECTED) */}
      {selectedCategory && subcategories.length > 0 && (
        <div className="space-y-2.5 animate-in fade-in duration-300">
          <label className="text-[10px] font-black text-white/40 tracking-widest uppercase block">
            {t.filterSubcategory} / الفئة الفرعية
          </label>
          <div className="flex flex-col gap-1.5">
            <button
              onClick={() => setSelectedSubcategory("")}
              className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                selectedSubcategory === ""
                  ? "bg-[#ff510a] text-white shadow-md shadow-orange-900/40"
                  : "bg-black/30 text-white/60 border border-white/5 hover:text-white hover:bg-white/5"
              }`}
            >
              {lang === "fr" ? "Toutes les sous-catégories" : "كل الفروع"}
            </button>
            {subcategories.map((sub) => (
              <button
                key={sub.id}
                onClick={() => setSelectedSubcategory(sub.id)}
                className={`w-full text-left px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                  selectedSubcategory === sub.id
                    ? "bg-[#ff510a] text-white shadow-md shadow-orange-900/40"
                    : "bg-black/30 text-white/60 border border-white/5 hover:text-white hover:bg-white/5"
                }`}
              >
                {sub.name[lang]}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* BRAND SELECTOR */}
      <div className="space-y-2.5">
        <label className="text-[10px] font-black text-white/40 tracking-widest uppercase block">
          {t.filterBrand} / الماركة
        </label>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setSelectedBrand("")}
            className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
              selectedBrand === ""
                ? "bg-[#0071d1] text-white shadow-sm"
                : "bg-black/30 border border-white/5 text-white/60 hover:text-white"
            }`}
          >
            {t.all}
          </button>
          {["Nike", "Adidas", "Puma", "Autres Marques"].map((br) => (
            <button
              key={br}
              onClick={() => setSelectedBrand(br === selectedBrand ? "" : br)}
              className={`px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                selectedBrand === br
                  ? "bg-[#0071d1] text-white shadow-sm font-black"
                  : "bg-black/30 border border-white/5 text-white/60 hover:text-white"
              }`}
            >
              {br}
            </button>
          ))}
        </div>
      </div>

      {/* SIZE FILTER */}
      <div className="space-y-2.5">
        <label className="text-[10px] font-black text-white/40 tracking-widest uppercase block">
          {t.filterSize} / المقاس
        </label>
        <div className="grid grid-cols-4 gap-1.5">
          {sizesList.map((sz) => (
            <button
              key={sz}
              onClick={() => setSelectedSize(sz === selectedSize ? "" : sz)}
              className={`py-2 rounded-lg text-center font-mono text-[11px] font-black cursor-pointer transition-all ${
                selectedSize === sz
                  ? "bg-[#ff510a] text-white font-black shadow-md"
                  : "bg-black/30 border border-white/5 text-white/60 hover:text-white"
              }`}
            >
              {sz}
            </button>
          ))}
        </div>
      </div>

      {/* COLOR FILTER */}
      <div className="space-y-2.5">
        <label className="text-[10px] font-black text-white/40 tracking-widest uppercase block">
          {t.filterColor} / اللون
        </label>
        <div className="flex flex-wrap gap-1.5">
          {colorsList.map((col) => (
            <button
              key={col}
              onClick={() => setSelectedColor(col === selectedColor ? "" : col)}
              className={`px-3 py-1.5 rounded-lg text-center text-[10px] sm:text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                selectedColor === col
                  ? "bg-[#0071d1] text-white font-black shadow-sm"
                  : "bg-[#0f172a] border border-white/5 text-white/60 hover:text-white"
              }`}
            >
              {col}
            </button>
          ))}
        </div>
      </div>

      {/* PRICE RANGE FILTER */}
      <div className="space-y-2.5">
        <div className="flex justify-between items-center text-[10px] font-black text-white/40 tracking-widest uppercase">
          <span>{t.price} / السعر</span>
          <span className="text-[#0071d1] font-sans font-black">{maxPrice.toLocaleString()} {t.currency}</span>
        </div>
        <div className="space-y-1">
          <input
            id="price-range-slider"
            type="range"
            min="1000"
            max="200000"
            step="1000"
            value={maxPrice}
            onChange={(e) => setMaxPrice(parseInt(e.target.value))}
            className="w-full h-1.5 bg-black/60 rounded-lg appearance-none cursor-pointer accent-[#0071d1]"
          />
          <div className="flex justify-between text-[9px] text-[#ff510a] font-mono font-black select-none">
            <span>1,000 DA</span>
            <span>200,000 DA</span>
          </div>
        </div>
      </div>

    </div>
  );
}
