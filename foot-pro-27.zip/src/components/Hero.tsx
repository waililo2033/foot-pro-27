import { Sparkles, ArrowRight, ShieldCheck, Truck, Zap } from "lucide-react";
import { TRANSLATIONS } from "../data/products";
// @ts-ignore
import nikeBoot from "../assets/images/nike_mercurial_vapor_1780429800398.png";

interface HeroProps {
  lang: "fr" | "ar";
  onNavigate: (hash: string) => void;
}

export default function Hero({ lang, onNavigate }: HeroProps) {
  const t = TRANSLATIONS[lang];

  return (
    <section className="relative overflow-hidden bg-[#020617] pt-12 pb-20 lg:pt-20 lg:pb-32 border-b border-white/10">
      {/* Abstract Design Elements matching Vibrant Palette */}
      <div className="absolute -top-20 -left-20 w-80 h-80 bg-[#0071d1]/20 blur-[120px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#ff510a]/10 blur-[155px] rounded-full pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Hero Content Left */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-left">
            {/* Tagline Badge matching design */}
            <div className="inline-block px-3 py-1.5 bg-[#ff510a] text-[10px] font-black uppercase tracking-widest text-white select-none">
              100% ORIGINAL IMPORT
            </div>

            {/* Main Headlines */}
            <div className="space-y-4">
              <h1 className="font-sans text-3xl sm:text-6xl font-black italic text-white uppercase tracking-tighter leading-tight">
                {lang === "fr" ? (
                  <>
                    Dominez Le Terrain<br />
                    <span className="text-[#ff510a]">Dès Le 1er Pas</span>
                  </>
                ) : (
                  <>
                    سيطر على الملعب<br />
                    <span className="text-[#ff510a]">من الخطوة الأولى</span>
                  </>
                )}
              </h1>
            </div>

            {/* Quick Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                id="hero-cta-shop"
                onClick={() => onNavigate("#/products")}
                className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-[#ff510a] hover:bg-[#ff510a]/90 text-white font-black text-xs tracking-widest uppercase transition-transform active:scale-95 shadow-lg shadow-[#ff510a]/20 cursor-pointer"
              >
                {t.allProducts}
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                id="hero-cta-about"
                onClick={() => onNavigate("#/about")}
                className="inline-flex items-center justify-center gap-3 px-8 py-4 bg-white/5 border border-white/10 hover:border-white/20 hover:bg-white/10 text-white font-black text-xs tracking-widest uppercase transition-all cursor-pointer"
              >
                {t.about}
              </button>
            </div>

            {/* Brand Core Promises */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/10 max-w-lg">
              <div className="space-y-1 select-none">
                <div className="flex items-center gap-1.5 text-xs font-black text-white uppercase">
                  <ShieldCheck className="w-4 h-4 text-[#ff510a]" />
                  Original
                </div>
                <p className="text-[10px] text-white/40 font-medium">Garanti authentique d'Europe</p>
              </div>
              <div className="space-y-1 select-none">
                <div className="flex items-center gap-1.5 text-xs font-black text-white uppercase">
                  <Truck className="w-4 h-4 text-[#0071d1]" />
                  58 Wilayas
                </div>
                <p className="text-[10px] text-white/40 font-medium">Livraison rapide à domicile</p>
              </div>
              <div className="space-y-1 select-none">
                <div className="flex items-center gap-1.5 text-xs font-black text-white uppercase">
                  <Zap className="w-4 h-4 text-emerald-500" />
                  WhatsApp
                </div>
                <p className="text-[10px] text-white/40 font-medium">Commande instantanée en 1-clic</p>
              </div>
            </div>
          </div>

          {/* Hero Premium Boot Display Right */}
          <div className="lg:col-span-5 relative flex justify-center">
            {/* Visual glow frame backing */}
            <div className="absolute inset-0 bg-gradient-to-tr from-[#0071d1]/20 to-[#ff510a]/20 blur-3xl opacity-30 rounded-full scale-75 pointer-events-none select-none animate-pulse"></div>

            <div className="relative max-w-sm sm:max-w-md bg-white/5 border border-white/10 p-5 rounded-2xl backdrop-blur-sm shadow-2xl hover:border-[#0071d1]/50 transition-all duration-500 group">
              <div className="absolute -top-3 -right-3 bg-[#ff510a] text-white text-[9px] font-black tracking-widest px-3 py-1.5 rounded-sm select-none transform rotate-3 shadow-md">
                HOT ITEM
              </div>
              
              <img
                src={nikeBoot}
                alt="Nike Mercurial Vapor Elite"
                referrerPolicy="no-referrer"
                className="w-full h-auto drop-shadow-[0_25px_60px_rgba(0,113,209,0.4)] object-contain transition-transform duration-700 ease-out group-hover:scale-105 group-hover:rotate-1"
              />

              <div className="mt-4 p-4 bg-black/40 rounded-xl border border-white/5">
                <div className="flex justify-between items-center select-none">
                  <div>
                    <span className="text-[10px] text-[#ff510a] font-mono font-black uppercase tracking-wider block">Nike Professional</span>
                    <h3 className="text-sm font-black text-white uppercase tracking-tight">Mercurial Vapor 15</h3>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-white/55 font-bold line-through block">29,500 DA</span>
                    <span className="text-sm font-black text-[#0071d1]">26,000 DA</span>
                  </div>
                </div>
                <button
                  id="hero-buy-featured"
                  onClick={() => onNavigate("#/product/nike-mercurial-vapor")}
                  className="w-full mt-4 py-3 rounded-lg bg-[#0071d1] hover:bg-[#0071d1]/90 text-white text-xs font-black uppercase tracking-wider transition-all cursor-pointer"
                >
                  {lang === "fr" ? "Commander l'original" : "اطلب المنتج الأصلي"}
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
