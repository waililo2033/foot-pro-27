import { useState } from "react";
import { MessageCircle, X } from "lucide-react";
import { TRANSLATIONS } from "../data/products";

interface WhatsAppFloatingProps {
  lang: "fr" | "ar";
}

export default function WhatsAppFloating({ lang }: WhatsAppFloatingProps) {
  const [showTooltip, setShowTooltip] = useState(true);
  const t = TRANSLATIONS[lang];

  const handleWhatsAppRedirect = () => {
    const greeting = lang === "fr"
      ? "Bonjour Foot Pro 27, je visite votre site et je souhaite me renseigner sur les équipements disponibles."
      : "السلام عليكم فوت برو 27، أنا أتصفح موقعكم وأرغب في الاستفسار عن الأجهزة والمنتجات المتاحة وتفاصيل المقاسات.";
    
    const url = `https://wa.me/213540344572?text=${encodeURIComponent(greeting)}`;
    window.open(url, "_blank");
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2 pointer-events-none select-none">
      {/* Dynamic Pop Tooltip */}
      {showTooltip && (
        <div className="pointer-events-auto flex items-center bg-emerald-600 text-white rounded-2xl py-2 pl-4 pr-3 shadow-2xl border border-emerald-500/30 text-xs font-bold font-sans animate-bounce relative max-w-[240px] md:max-w-xs">
          <span className="leading-tight mr-1">
            {t.whatsappFloatingTooltip}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowTooltip(false);
            }}
            className="p-1 rounded-full text-emerald-100 hover:text-white hover:bg-emerald-700/50 transition-colors ml-1 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          
          {/* Tooltip speech bubble tail arrow */}
          <div className="absolute bottom-[-6px] right-5 w-3 h-3 bg-emerald-600 rotate-45 border-r border-b border-emerald-500/30"></div>
        </div>
      )}

      {/* Pulsing Floating Button */}
      <button
        id="btn-whatsapp-floating"
        onClick={handleWhatsAppRedirect}
        className="pointer-events-auto w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-3xl shadow-emerald-500/30 hover:scale-110 active:scale-95 transition-all cursor-pointer relative group"
        aria-label="Order or Chat on WhatsApp"
      >
        {/* Glow pulsing effect */}
        <span className="absolute inset-0 rounded-full bg-emerald-400 opacity-75 animate-ping -z-10 group-hover:block hidden"></span>
        
        <MessageCircle className="w-7 h-7 fill-current" />
      </button>
    </div>
  );
}
