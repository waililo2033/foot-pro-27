import { TRANSLATIONS } from "../data/products";
import { Phone, MapPin, Truck, ShieldCheck, Mail, HelpingHand } from "lucide-react";

interface FooterProps {
  lang: "fr" | "ar";
  onNavigate: (hash: string) => void;
}

export default function Footer({ lang, onNavigate }: FooterProps) {
  const t = TRANSLATIONS[lang];
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (hash: string) => {
    onNavigate(hash);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-[#050b15] border-t border-white/10 text-white/70 select-none">
      
      {/* Aesthetic Brands Ribbon */}
      <div className="bg-black/40 border-b border-white/10 py-6 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8 whitespace-nowrap">
          <div className="text-white/20 font-black text-md sm:text-xl italic flex gap-8 sm:gap-12 select-none tracking-wider">
            <span>NIKE</span>
            <span>ADIDAS</span>
            <span>PUMA</span>
            <span>MIZUNO</span>
            <span>UMBRO</span>
            <span>NEW BALANCE</span>
          </div>
          <div className="flex items-center gap-4 text-left">
            <div className="flex flex-col text-right">
              <span className="text-[9px] font-black tracking-widest text-[#ff510a]">SUPPORT 24/7</span>
              <span className="text-xs sm:text-sm font-black text-white">+213 540 344 572</span>
            </div>
            <div className="w-10 h-10 bg-white/5 border border-white/10 rounded-full flex items-center justify-center">
              <Mail className="w-4 h-4 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Top Value Propositions */}
      <div className="border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center sm:text-left">
            <div className="flex flex-col sm:flex-row items-center gap-4 p-5 rounded-2xl bg-[#0f172a] border border-white/5">
              <ShieldCheck className="w-10 h-10 text-[#0071d1] flex-shrink-0" />
              <div className="text-left">
                <h4 className="text-xs font-black text-white uppercase tracking-wider">{lang === "fr" ? "100% IMPORTÉ" : "منتجات أصلية 100%"}</h4>
                <p className="text-[11px] text-white/50 mt-1">{lang === "fr" ? "Aucune contrefaçon, import direct d'Europe." : "سلع أصلية مستوردة من الموزعين الرسميين بأوروبا."}</p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-4 p-5 rounded-2xl bg-[#0f172a] border border-white/5">
              <Truck className="w-10 h-10 text-[#ff510a] flex-shrink-0" />
              <div className="text-left">
                <h4 className="text-xs font-black text-white uppercase tracking-wider">{lang === "fr" ? "LIVRAISON WILAYAS" : "توصيل سريع لكافة الولايات"}</h4>
                <p className="text-[11px] text-white/50 mt-1">{lang === "fr" ? "Livraison sécurisée sur les 58 wilayas." : "توصيل سريع وموثوق لباب منزلك في 58 ولاية."}</p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-4 p-5 rounded-2xl bg-[#0f172a] border border-white/5">
              <HelpingHand className="w-10 h-10 text-emerald-400 flex-shrink-0" />
              <div className="text-left">
                <h4 className="text-xs font-black text-white uppercase tracking-wider">{lang === "fr" ? "ASSISTANCE DIRECTE" : "مساعدة مستمرة عبر واتساب"}</h4>
                <p className="text-[11px] text-white/50 mt-1">{lang === "fr" ? "Conseils de tailles et choix 24h/7." : "نحن معك خطوة بخطوة لاختيار مقاسك ومواصفات طلبك."}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links & Bio Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12 text-left">
          
          {/* Column 1: Store Branding & Location */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => handleLinkClick("#/")}>
              <div className="w-10 h-10 bg-[#ff510a] rounded-lg flex items-center justify-center rotate-3">
                <span className="font-sans font-black text-white text-lg italic">27</span>
              </div>
              <span className="font-sans text-xl font-black text-white uppercase tracking-tighter">
                FOOT PRO <span className="text-[#0071d1]">27</span>
              </span>
            </div>
            
            <p className="text-xs sm:text-sm text-white/50 leading-relaxed max-w-sm">
              {lang === "fr" 
                ? "Le magasin de football numéro 1 d'importation en Algérie. Retrouvez des crampons originaux, des maillots officiels et vos accessoires d'entraînement préférés."
                : "المتجر الأول في الجزائر لاستيراد وتوفير مستلزمات ومعدات كرة القدم الأصلية والاحترافية. نوفر الجودة العالية والنادرة التي تليق بشغفك الرياضي."}
            </p>

            <div className="space-y-2.5 pt-2 text-xs">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#ff510a] mt-0.5 flex-shrink-0 animate-pulse" />
                <span>{t.location}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#0071d1] flex-shrink-0" />
                <a href="tel:+213540344572" className="hover:text-[#ff510a] transition-colors font-black">
                  +213 540 344 572
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-white/40 flex-shrink-0" />
                <span className="font-mono">contact@footpro27.dz</span>
              </div>
            </div>
          </div>

          {/* Column 2: Navigation Links */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="text-white text-xs font-black uppercase tracking-widest font-mono">
              {lang === "fr" ? "Navigation" : "روابط سريعة"}
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button onClick={() => handleLinkClick("#/")} className="hover:text-[#0071d1] transition-colors cursor-pointer text-left uppercase font-black tracking-wider text-xs">
                  {t.home}
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick("#/products")} className="hover:text-[#0071d1] transition-colors cursor-pointer text-left uppercase font-black tracking-wider text-xs">
                  {t.allProducts}
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick("#/about")} className="hover:text-[#0071d1] transition-colors cursor-pointer text-left uppercase font-black tracking-wider text-xs">
                  {t.about}
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick("#/contact")} className="hover:text-[#0071d1] transition-colors cursor-pointer text-left uppercase font-black tracking-wider text-xs">
                  {t.contact}
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Utility & Legal Pages */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-white text-xs font-black uppercase tracking-widest font-mono">
              {lang === "fr" ? "Informations & Support" : "المعلومات والدعم"}
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button onClick={() => handleLinkClick("#/faq")} className="hover:text-[#0071d1] transition-colors cursor-pointer text-left uppercase font-black tracking-wider text-xs">
                  {t.faq}
                </button>
              </li>
              <li>
                <button onClick={() => handleLinkClick("#/privacy")} className="hover:text-[#0071d1] transition-colors cursor-pointer text-left uppercase font-black tracking-wider text-xs">
                  {t.privacy}
                </button>
              </li>
              <li>
                <div className="text-white/40 font-mono text-[10px] sm:text-xs">
                  {lang === "fr" 
                    ? "Besoin d'un devis d'équipe ? Contactez directement nos conseillers sur WhatsApp."
                    : "هل تريد تجهيز فريقك بالكامل؟ تواصل معنا مباشرة على واتساب وسنوفر لك أفضل الأسعار."}
                </div>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Credits banner */}
        <div className="mt-12 pt-8 border-t border-white/10 text-center flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] sm:text-xs text-white/30 uppercase tracking-widest font-black">
          <div>
            &copy; {currentYear} {t.storeName}. {t.allRightsReserved}
          </div>
          <div className="flex items-center gap-4 font-mono">
            <span>Massra, Mostaganem, Algeria • Wilaya 27</span>
            <span className="text-white/25">|</span>
            <button
              onClick={() => handleLinkClick("#/admin")}
              className="text-[#0071d1] hover:text-[#ff510a] transition-colors cursor-pointer flex items-center gap-1.2 font-sans font-black"
            >
              ⚙️ CMS Studio
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
