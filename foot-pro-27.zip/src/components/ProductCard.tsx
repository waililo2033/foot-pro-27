import React from "react";
import { ChevronRight, Award, Zap } from "lucide-react";
import { Product, TRANSLATIONS } from "../data/products";

interface ProductCardProps {
  key?: string | number;
  product: Product;
  lang: "fr" | "ar";
  onNavigate: (hash: string) => void;
}

export default function ProductCard({
  product,
  lang,
  onNavigate,
}: ProductCardProps) {
  const t = TRANSLATIONS[lang];

  return (
    <div
      id={`product-card-${product.id}`}
      className="group bg-[#0f172a] border border-white/5 rounded-2xl overflow-hidden hover:border-[#0071d1] hover:shadow-2xl hover:shadow-black/50 transition-all duration-300 flex flex-col h-full"
    >
      {/* Product Image Panel */}
      <div className="relative aspect-square bg-white/5 overflow-hidden flex items-center justify-center p-4 sm:p-6 group-hover:bg-white/10 transition-colors">
        {/* Badges */}
        <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 select-none">
          {product.isNew && (
            <span className="inline-block bg-[#0071d1] text-white text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-sm shadow-md animate-pulse">
              NEW
            </span>
          )}
          {product.isBestSeller && (
            <span className="inline-block bg-[#ff510a] text-white text-[9px] font-black uppercase tracking-widest px-2.5 py-1 rounded-sm shadow-md">
              BEST
            </span>
          )}
        </div>

        {/* Brand overlay tag */}
        <div className="absolute top-3 right-3 text-[9px] font-mono tracking-widest text-white/40 font-black uppercase select-none">
          {product.brand}
        </div>

        {/* Image */}
        <img
          src={product.image}
          alt={product.name[lang]}
          referrerPolicy="no-referrer"
          loading="lazy"
          className="w-full h-full object-contain max-h-[180px] drop-shadow-[0_15px_30px_rgba(0,0,0,0.7)] group-hover:scale-105 transition-transform duration-500 ease-out"
        />
      </div>

      {/* Product Information */}
      <div className="p-4 flex flex-col flex-1 text-left space-y-3">
        {/* Brand & Subcategory Label */}
        <div className="flex justify-between items-center text-[10px] uppercase font-black tracking-widest font-mono">
          <span className="text-[#ff510a]">
            {product.brand}
          </span>
          <span className="text-white/40">
            {product.subcategory}
          </span>
        </div>

        {/* Title */}
        <h3 className="font-sans text-sm sm:text-base font-black text-white line-clamp-1 group-hover:text-[#0071d1] transition-colors leading-tight uppercase">
          {product.name[lang]}
        </h3>

        {/* Price Tag */}
        <div className="flex items-baseline justify-between select-none">
          <div className="flex items-baseline gap-1">
            <span className="text-base sm:text-lg font-black text-white">
              {product.price.toLocaleString()}
            </span>
            <span className="text-[10px] text-white/50 font-black">{t.currency}</span>
          </div>
          {/* Quick stock/original cue */}
          {product.inStock === false || product.stockCount === 0 ? (
            <span className="flex items-center gap-1 text-[9px] text-red-500 font-bold uppercase tracking-wider">
              {lang === "fr" ? "Épuisé" : "نفذت"}
            </span>
          ) : product.stockCount !== undefined && product.stockCount <= 3 ? (
            <span className="flex items-center gap-1 text-[9px] text-orange-400 font-bold uppercase tracking-wider">
              {lang === "fr" ? "Limité" : "محدود"}
            </span>
          ) : (
            <span className="flex items-center gap-1 text-[9px] text-white/40 font-black uppercase tracking-wider">
              <Award className="w-3.5 h-3.5 text-[#ff510a]" />
              Original
            </span>
          )}
        </div>

        {/* CTA Button Block */}
        <div className="pt-2 mt-auto">
          <button
            id={`btn-view-${product.id}`}
            onClick={() => onNavigate(`#/product/${product.id}`)}
            className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 border border-white/10 text-white/80 group-hover:text-white hover:bg-white/10 group-hover:border-[#0071d1] text-xs font-black uppercase tracking-wider cursor-pointer transition-all"
          >
            {t.viewDetails}
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
}
