import React, { useState, useEffect } from "react";
import { Search, Menu, X, Globe, Phone, MapPin, Truck } from "lucide-react";
import { TRANSLATIONS } from "../data/products";
// @ts-ignore
import logoImg from "../assets/images/logo.png";

interface NavbarProps {
  lang: "fr" | "ar";
  setLang: (lang: "fr" | "ar") => void;
  activeHash: string;
  onNavigate: (hash: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export default function Navbar({
  lang,
  setLang,
  activeHash,
  onNavigate,
  searchQuery,
  setSearchQuery,
}: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const t = TRANSLATIONS[lang];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { hash: "#/", label: t.home },
    { hash: "#/products", label: t.allProducts },
    { hash: "#/about", label: t.about },
    { hash: "#/contact", label: t.contact },
    { hash: "#/faq", label: t.faq },
    { hash: "#/privacy", label: t.privacy },
  ];

  const handleLinkClick = (hash: string) => {
    onNavigate(hash);
    setIsOpen(false);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNavigate("#/products");
  };

  return (
    <header className="sticky top-0 z-50 w-full transition-all duration-300">
      {/* Main Navigation */}
      <nav
        className={`w-full transition-all duration-300 ${
          scrolled
            ? "bg-[#050b15]/95 backdrop-blur-md shadow-lg border-b border-white/10"
            : "bg-[#050b15] border-b border-white/10"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20 gap-4">
            {/* Logo */}
            <div className="flex-shrink-0 flex items-center">
              <button
                id="nav-logo"
                onClick={() => handleLinkClick("#/")}
                className="flex items-center gap-3 group text-left cursor-pointer"
              >
                <img
                  src={logoImg}
                  alt="Foot Pro 27"
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 object-contain group-hover:scale-105 transition-all duration-300"
                />
                <div>
                  <span className="font-sans text-xl sm:text-2xl font-black text-white tracking-tighter uppercase block leading-none">
                    FOOT PRO <span className="text-[#0071d1]">27</span>
                  </span>
                </div>
              </button>
            </div>

            {/* Desktop Navigation Links */}
            <div className="hidden lg:flex items-center space-x-1 xl:space-x-2">
              {navLinks.map((link) => {
                const isActive = activeHash === link.hash || 
                  (link.hash === "#/products" && activeHash.startsWith("#/product/"));
                return (
                  <button
                    key={link.hash}
                    id={`nav-link-${link.hash.replace("#/", "") || "home"}`}
                    onClick={() => handleLinkClick(link.hash)}
                    className={`px-3 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                      isActive
                        ? "text-[#ff510a] border-b-2 border-[#ff510a] rounded-b-none"
                        : "text-white/80 hover:text-[#0071d1]"
                    }`}
                  >
                    {link.label}
                  </button>
                );
              })}
            </div>

            {/* Action Group: Search & Language & Admin */}
            <div className="hidden lg:flex items-center gap-4">
              {/* Search Input Box */}
              <form
                onSubmit={handleSearchSubmit}
                className="relative max-w-xs"
              >
                <input
                  id="search-input-desktop"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  className="w-48 bg-white/5 border border-white/10 rounded-full py-2 px-4 pl-4 pr-8 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#0071d1] focus:ring-1 focus:ring-[#0071d1] focus:w-60 transition-all duration-300"
                />
                <button
                  type="submit"
                  id="search-button-desktop"
                  className="absolute right-3 top-2 text-white/50 hover:text-[#ff510a] transition-colors cursor-pointer"
                >
                  <Search className="w-3.5 h-3.5" />
                </button>
              </form>

              {/* Language Switcher Badge */}
              <div className="flex items-center gap-1 bg-white/5 border border-white/10 p-1 rounded-full select-none">
                <button
                  id="btn-lang-fr"
                  onClick={() => setLang("fr")}
                  className={`px-2 py-1 rounded-full text-[10px] font-black transition-all duration-200 cursor-pointer ${
                    lang === "fr"
                      ? "bg-[#ff510a] text-white shadow-sm"
                      : "hover:bg-white/5 text-white/60"
                  }`}
                >
                  FR
                </button>
                <button
                  id="btn-lang-ar"
                  onClick={() => setLang("ar")}
                  className={`px-2 py-1 rounded-full text-[10px] font-black transition-all duration-200 cursor-pointer ${
                    lang === "ar"
                      ? "bg-[#ff510a] text-white shadow-sm"
                      : "hover:bg-white/5 text-white/60"
                  }`}
                >
                  AR
                </button>
              </div>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex lg:hidden items-center gap-2">
              <button
                id="mobile-menu-btn"
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white focus:outline-none cursor-pointer"
              >
                {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Panel */}
        {isOpen && (
          <div className="lg:hidden border-t border-white/10 bg-[#050b15] px-4 pt-4 pb-6 space-y-4 shadow-xl animate-in fade-in slide-in-from-top-5 duration-200">
            {/* Search Box on Mobile */}
            <form onSubmit={handleSearchSubmit} className="relative w-full">
              <input
                id="search-input-mobile"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full bg-white/5 border border-white/10 rounded-full py-2.5 pl-5 pr-10 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#0071d1]"
              />
              <button
                type="submit"
                id="search-button-mobile"
                className="absolute right-4 top-3 text-white/50 cursor-pointer"
              >
                <Search className="w-4.5 h-4.5" />
              </button>
            </form>

            {/* Language Selector in Mobile */}
            <div className="flex items-center justify-between px-3 py-2 bg-white/5 rounded-xl">
              <span className="text-xs font-black text-white/50 uppercase tracking-widest flex items-center gap-1.5 select-none">
                <Globe className="w-4 h-4 text-[#0071d1]" />
                {lang === "fr" ? "Langue" : "اللغة"}
              </span>
              <div className="flex bg-black/40 p-1 rounded-lg">
                <button
                  onClick={() => setLang("fr")}
                  className={`px-3 py-1 rounded-md text-[10px] font-black cursor-pointer transition-all ${
                    lang === "fr" ? "bg-[#ff510a] text-white shadow-sm" : "text-white/60"
                  }`}
                >
                  Français
                </button>
                <button
                  onClick={() => setLang("ar")}
                  className={`px-3 py-1 rounded-md text-[10px] font-black cursor-pointer transition-all ${
                    lang === "ar" ? "bg-[#ff510a] text-white shadow-sm" : "text-white/60"
                  }`}
                >
                  العربية
                </button>
              </div>
            </div>

            {/* Links Stack */}
            <div className="space-y-1.5">
              {navLinks.map((link) => {
                const isActive = activeHash === link.hash ||
                  (link.hash === "#/products" && activeHash.startsWith("#/product/"));
                return (
                  <button
                    key={link.hash}
                    id={`mobile-nav-link-${link.hash.replace("#/", "") || "home"}`}
                    onClick={() => handleLinkClick(link.hash)}
                    className={`w-full text-left px-4 py-3 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                      isActive
                        ? "bg-[#ff510a]/10 text-[#ff510a] border-l-4 border-[#ff510a]"
                        : "text-white/80 hover:text-[#0071d1] hover:bg-white/5"
                    }`}
                  >
                    {link.label}
                  </button>
                );
              })}
            </div>

            {/* Micro Details */}
            <div className="pt-4 border-t border-white/10 text-xs text-white/50 space-y-2 px-2 select-none">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#ff510a]" />
                {t.location}
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#0071d1]" />
                +213 540 344 572
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
