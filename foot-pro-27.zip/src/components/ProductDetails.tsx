import { useState, useEffect } from "react";
import { ArrowLeft, CheckCircle, Truck, RefreshCw, MessageSquare, ShieldCheck, AlertTriangle } from "lucide-react";
import { Product, TRANSLATIONS, CATEGORIES } from "../data/products";

interface ProductDetailsProps {
  product: Product;
  lang: "fr" | "ar";
  onNavigate: (hash: string) => void;
}

export default function ProductDetails({
  product,
  lang,
  onNavigate,
}: ProductDetailsProps) {
  const t = TRANSLATIONS[lang];
  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || "");
  const [selectedColor, setSelectedColor] = useState(product.colors[lang][0] || "");

  // Scroll to top on load details
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [product.id]);

  const handleOrderWhatsApp = () => {
    const parentCategory = CATEGORIES.find((c) => c.id === product.category);
    const categoryName = parentCategory ? parentCategory.name[lang] : product.category;
    const subcategoryName = product.subcategory;

    const message = `السلام عليكم،

أرغب في طلب المنتج التالي:

المنتج: ${product.name[lang]}
الفئة: ${categoryName} - ${subcategoryName}
المقاس: ${selectedSize}
اللون: ${selectedColor}
السعر: ${product.price.toLocaleString()} ${t.currency}

شكراً.`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/213540344572?text=${encodedMessage}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Back Button */}
      <div className="mb-6 text-left">
        <button
          id="btn-back-to-store"
          onClick={() => onNavigate("#/products")}
          className="inline-flex items-center gap-2 text-xs font-black text-white/40 hover:text-[#0071d1] uppercase tracking-widest transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          {lang === "fr" ? "Retour à l'inventaire" : "الرجوع للمعرض الرئيسي"}
        </button>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start bg-[#0f172a] border border-white/5 p-5 sm:p-8 rounded-2xl shadow-2xl">
        
        {/* Left Side: Product Image Display */}
        <div className="lg:col-span-6 space-y-4">
          <div className="aspect-square bg-black/30 rounded-2xl overflow-hidden flex items-center justify-center p-6 border border-white/5 relative group select-none">
            {/* Visual Tags */}
            <div className="absolute top-4 left-4 flex flex-col gap-1.5 z-10">
              {product.isNew && (
                <span className="inline-block bg-[#0071d1] text-white text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-sm shadow-md">
                  NEW
                </span>
              )}
              {product.isBestSeller && (
                <span className="inline-block bg-[#ff510a] text-white text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-sm shadow-md">
                  BEST
                </span>
              )}
            </div>

            <img
              src={product.image}
              alt={product.name[lang]}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain max-h-[320px] sm:max-h-[380px] drop-shadow-[0_25px_50px_rgba(0,0,0,0.8)] group-hover:scale-105 transition-transform duration-500 ease-out"
            />
          </div>
          
          <div className="text-center text-[10px] text-white/40 font-mono tracking-widest flex items-center justify-center gap-1.5 select-none font-bold uppercase">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            Original importé d'Europe • Foot Pro 27
          </div>
        </div>

        {/* Right Side: Information Panels */}
        <div className="lg:col-span-6 space-y-6 text-left">
          {/* Brand & Subcategory Breadcrumb */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-black text-[#0071d1] uppercase font-mono tracking-wider">
              <span>{product.brand}</span>
              <span className="text-white/20">•</span>
              <span className="text-white/40">{product.subcategory}</span>
            </div>
            <h1 className="font-sans text-2xl sm:text-4xl font-black text-white tracking-tight leading-none uppercase">
              {product.name[lang]}
            </h1>
          </div>

          {/* Pricing Tag */}
          <div className="p-5 bg-black/40 rounded-xl border border-white/5 flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center select-none animate-in fade-in duration-300">
            <div>
              <span className="text-[10px] text-white/40 block uppercase font-mono tracking-wider font-black">
                Prix Foot Pro 27
              </span>
              <span className="text-3xl font-black text-white font-mono tracking-tight">
                {product.price.toLocaleString()}
              </span>
              <span className="text-xs font-black text-[#0071d1] ml-1.5">{t.currency}</span>
            </div>

            {product.inStock === false || product.stockCount === 0 ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-red-500/10 border border-red-500/20 text-red-500 rounded-lg text-[9px] font-black tracking-widest uppercase font-mono">
                <AlertTriangle className="w-3.5 h-3.5" />
                {lang === "fr" ? "RUPTURE DE STOCK" : "نفذت الكمية"}
              </span>
            ) : product.stockCount !== undefined && product.stockCount <= 3 ? (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-orange-500/10 border border-orange-500/20 text-orange-400 rounded-lg text-[9px] font-black tracking-widest uppercase font-mono">
                <AlertTriangle className="w-3.5 h-3.5" />
                {lang === "fr" ? `STOCK LIMITÉ (${product.stockCount} RESTANTS)` : `كمية محدودة جداً (${product.stockCount} متبقي)`}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-lg text-[9px] font-black tracking-widest uppercase font-mono">
                <CheckCircle className="w-3.5 h-3.5" />
                {lang === "fr" ? "STOCK DISPONIBLE" : "متوفر في المخزن"}
              </span>
            )}
          </div>

          {/* Description Text */}
          <div className="space-y-2">
            <h3 className="text-[10px] font-black uppercase tracking-widest text-[#0071d1] font-mono">
              Description / المواصفات
            </h3>
            <p className="text-xs sm:text-sm text-white/70 leading-relaxed font-semibold">
              {product.description[lang]}
            </p>
          </div>

          {/* COLOR SELECTOR */}
          <div className="space-y-3">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-white/40 font-mono">
              {t.filterColor} / اللون: <span className="text-white normal-case font-sans font-black">{selectedColor}</span>
            </h4>
            <div className="flex flex-wrap gap-2">
              {product.colors[lang].map((col) => (
                <button
                  key={col}
                  id={`color-${col}`}
                  onClick={() => setSelectedColor(col)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider cursor-pointer transition-all ${
                    selectedColor === col
                      ? "bg-[#0071d1] text-white shadow-md shadow-blue-900/30"
                      : "bg-black/30 border border-white/5 text-white/60 hover:text-white"
                  }`}
                >
                  {col}
                </button>
              ))}
            </div>
          </div>

          {/* SIZE SELECTOR */}
          <div className="space-y-3">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-white/40 font-mono">
              {t.filterSize} / المقاس المتاح: <span className="text-white font-sans font-black">{selectedSize}</span>
            </h4>
            <div className="grid grid-cols-6 sm:grid-cols-8 gap-2">
              {product.sizes.map((sz) => (
                <button
                  key={sz}
                  id={`size-${sz}`}
                  onClick={() => setSelectedSize(sz)}
                  className={`py-3 rounded-xl text-xs font-mono font-black text-center cursor-pointer transition-all ${
                    selectedSize === sz
                      ? "bg-[#ff510a] text-white shadow-md shadow-orange-950/35"
                      : "bg-black/30 border border-white/5 text-white/60 hover:text-white"
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* ORDER CTA ACTION */}
          <div className="pt-2">
            {product.inStock === false || product.stockCount === 0 ? (
              <button
                id="btn-order-whatsapp-details"
                onClick={handleOrderWhatsApp}
                className="w-full inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 text-white/80 hover:text-white font-black text-xs tracking-widest uppercase shadow-lg cursor-pointer transition-all"
              >
                <MessageSquare className="w-5 h-5 fill-current text-white/50" />
                {lang === "fr" ? "Se renseigner ou Réserver sur WhatsApp" : "الاستعلام أو طلب الحجز عبر واتساب"}
              </button>
            ) : (
              <button
                id="btn-order-whatsapp-details"
                onClick={handleOrderWhatsApp}
                className="w-full inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-500 text-white font-black text-xs tracking-widest uppercase shadow-lg shadow-emerald-950/40 cursor-pointer transition-all"
              >
                <MessageSquare className="w-5 h-5 fill-current" />
                {t.commanderWhatsApp} (WhatsApp Only)
              </button>
            )}
            <span className="text-[10px] text-center text-white/40 font-black tracking-wider block mt-2.5">
              ⚠️ {lang === "fr" ? "SANS PAIEMENT EN LIGNE. NOUS TRAITONS L'INTÉGRALITÉ DE LA COMMANDE SUR WHATSAPP." : "طلب مباشر بدون دفع إلكتروني. نؤكد كامل طلبيتك ونخدمك على الواتساب."}
            </span>
          </div>

          {/* Feature details bullet lists */}
          <div className="pt-5 border-t border-white/10 space-y-3">
            <h4 className="text-[10px] font-black uppercase tracking-widest text-[#0071d1] font-mono">
              {lang === "fr" ? "Caractéristiques clés" : "المميزات والضمانات"}
            </h4>
            <ul className="text-xs text-white/70 space-y-2.5 font-semibold">
              {product.features[lang] ? (
                product.features[lang].map((feat, idx) => (
                  <li key={idx} className="flex gap-2 items-start leading-relaxed">
                    <span className="text-[#ff510a] mt-1 font-black leading-none">•</span>
                    <span>{feat}</span>
                  </li>
                ))
              ) : (
                <li className="flex gap-2 items-start">
                  <span className="text-[#ff510a]">•</span>
                  <span>Produit professionnel importé directement d'Europe.</span>
                </li>
              )}
            </ul>
          </div>

          {/* Trust Guarantees */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-5 border-t border-white/10">
            <div className="p-4 bg-black/40 rounded-xl border border-white/5 flex items-center gap-3.5 select-none">
              <Truck className="w-6 h-6 text-[#ff510a] flex-shrink-0" />
              <div className="text-left">
                <span className="text-[10px] font-black text-white block uppercase tracking-wider leading-none">
                  {lang === "fr" ? "LIVRAISON 58 WILAYAS" : "التوصيل لـ 58 ولاية"}
                </span>
                <span className="text-[10px] text-white/40 font-medium">{lang === "fr" ? "À domicile rapide" : "لباب المنزل سريع"}</span>
              </div>
            </div>
            <div className="p-4 bg-black/40 rounded-xl border border-white/5 flex items-center gap-3.5 select-none">
              <RefreshCw className="w-6 h-6 text-[#0071d1] flex-shrink-0 animate-spin-slow" />
              <div className="text-left">
                <span className="text-[10px] font-black text-white block uppercase tracking-wider leading-none">
                  {lang === "fr" ? "ÉCHANGE SOUS 48H" : "استبدال المقاس 48 سا"}
                </span>
                <span className="text-[10px] text-white/40 font-medium">{lang === "fr" ? "Garantie satisfaction" : "ضمان المقاس والجودة"}</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
