import React, { useState, useEffect, useMemo } from "react";
import { 
  ShoppingBag, 
  Sparkles, 
  MessageSquare, 
  Phone, 
  MapPin, 
  Clock, 
  HelpCircle, 
  ShieldAlert, 
  Info, 
  Mail, 
  Truck, 
  CornerDownLeft, 
  RotateCcw,
  Zap,
  ArrowRight,
  TrendingUp,
  Filter,
  CheckCircle,
  Menu,
  ChevronDown,
  Plus,
  Minus,
  Award,
  Facebook,
  Instagram,
  Settings,
  Trash2,
  Edit3,
  Lock,
  LockKeyhole,
  Image as ImageIcon,
  Search,
  Globe,
  Eye,
  EyeOff,
  Save,
  Upload,
  X
} from "lucide-react";

// Components
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import ProductCard from "./components/ProductCard";
import ProductDetails from "./components/ProductDetails";
import Filters from "./components/Filters";
import Footer from "./components/Footer";
import WhatsAppFloating from "./components/WhatsAppFloating";
import AdminDashboard from "./components/AdminDashboard";

// Data
import { PRODUCTS, TRANSLATIONS, CATEGORIES, BRANDS, Product } from "./data/products";
import { isSupabaseConfigured, fetchProductsFromDb } from "./lib/supabase";

export default function App() {
  const [lang, setLang] = useState<"fr" | "ar">("fr");
  const [activeHash, setActiveHash] = useState(window.location.hash || "#/");
  const [searchQuery, setSearchQuery] = useState("");

  // Dynamic products state for CMS
  const [productsList, setProductsList] = useState<Product[]>([]);

  // Smooth redirect for direct URL matching /admin
  useEffect(() => {
    if (window.location.pathname === "/admin" || window.location.pathname === "/admin/") {
      window.location.hash = "#/admin";
    }
  }, []);

  useEffect(() => {
    async function loadProducts() {
      if (isSupabaseConfigured()) {
        try {
          const dbProducts = await fetchProductsFromDb();
          if (dbProducts && dbProducts.length > 0) {
            setProductsList(dbProducts);
            return;
          }
        } catch (err) {
          console.error("Error reading from Supabase, loading fallback:", err);
        }
      }

      const raw = localStorage.getItem("footpro_products");
      if (raw) {
        try {
          setProductsList(JSON.parse(raw));
        } catch (err) {
          setProductsList(PRODUCTS);
        }
      } else {
        setProductsList(PRODUCTS);
        localStorage.setItem("footpro_products", JSON.stringify(PRODUCTS));
      }
    }
    loadProducts();
  }, []);

  // Filter States (price limit upgraded to 200,000 DA)
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedSubcategory, setSelectedSubcategory] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("");
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState("");
  const [maxPrice, setMaxPrice] = useState(200000);

  // Accordion State for FAQ
  const [faqOpenIdx, setFaqOpenIdx] = useState<number | null>(null);

  // Localization Dictionary Shortcut
  const t = TRANSLATIONS[lang];

  // Sync Document attributes for RTL support
  useEffect(() => {
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [lang]);

  // Routing Hash Change Listener
  useEffect(() => {
    const handleHashChange = () => {
      setActiveHash(window.location.hash || "#/");
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  const navigateTo = (hash: string) => {
    window.location.hash = hash;
  };

  const handleClearFilters = () => {
    setSelectedCategory("");
    setSelectedSubcategory("");
    setSelectedBrand("");
    setSelectedSize("");
    setSelectedColor("");
    setMaxPrice(200000);
    setSearchQuery("");
  };

  // Filter Products Logic
  const filteredProducts = useMemo(() => {
    return productsList.filter((p) => {
      // Search text matches (fuzzy matches Title, Brand, Color or Subcategory details)
      if (searchQuery.trim() !== "") {
        const query = searchQuery.toLowerCase();
        const matchesNameFr = p.name.fr.toLowerCase().includes(query);
        const matchesNameAr = p.name.ar.toLowerCase().includes(query);
        const matchesBrand = p.brand.toLowerCase().includes(query);
        const matchesColorFr = p.colors.fr.some((c) => c.toLowerCase().includes(query));
        const matchesColorAr = p.colors.ar.some((c) => c.toLowerCase().includes(query));
        const matchesSub = p.subcategory.toLowerCase().includes(query);
        const matchesCat = p.category.toLowerCase().includes(query);

        if (!matchesNameFr && !matchesNameAr && !matchesBrand && !matchesColorFr && !matchesColorAr && !matchesSub && !matchesCat) {
          return false;
        }
      }

      // Category match
      if (selectedCategory && p.category !== selectedCategory) return false;

      // Subcategory match
      if (selectedSubcategory && p.subcategory !== selectedSubcategory) return false;

      // Brand match (supports Nike, Adidas, Puma, and "Autres Marques" filter)
      if (selectedBrand) {
        if (selectedBrand === "Autres Marques") {
          const isCoreBrand = ["nike", "adidas", "puma"].includes(p.brand.toLowerCase());
          if (isCoreBrand) return false;
        } else if (p.brand !== selectedBrand) {
          return false;
        }
      }

      // Size match
      if (selectedSize && !p.sizes.includes(selectedSize)) return false;

      // Color match (Handles multi-lang color tags)
      if (selectedColor) {
        const hasColorFr = p.colors.fr.includes(selectedColor);
        const hasColorAr = p.colors.ar.includes(selectedColor);
        if (!hasColorFr && !hasColorAr) return false;
      }

      // Max Price match
      if (p.price > maxPrice) return false;

      return true;
    });
  }, [productsList, searchQuery, selectedCategory, selectedSubcategory, selectedBrand, selectedSize, selectedColor, maxPrice]);

  // Extract Details ID if on product details router path e.g. #/product/nike-mercurial-vapor
  const currentProductId = activeHash.startsWith("#/product/") 
    ? activeHash.replace("#/product/", "") 
    : null;

  const currentProduct = currentProductId 
    ? productsList.find((p) => p.id === currentProductId) 
    : null;

  // Best Sellers & New Arrivals lists
  const bestSellers = useMemo(() => productsList.filter((p) => p.isBestSeller), [productsList]);
  const newArrivals = useMemo(() => productsList.filter((p) => p.isNew), [productsList]);

  return (
    <div className={`min-h-screen bg-[#050b15] text-white font-sans antialiased flex flex-col selection:bg-[#0071d1] selection:text-white`}>
      {/* Header / Navbar Component */}
      <Navbar
        lang={lang}
        setLang={setLang}
        activeHash={activeHash}
        onNavigate={navigateTo}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main Page Render Routing */}
      <main className="flex-grow">
        
        {/* VIEW 1: HOME PAGE */}
        {(activeHash === "#/" || activeHash === "") && (
          <div className="animate-in fade-in duration-500">
            {/* Elegant Hero Banner */}
            <Hero lang={lang} onNavigate={navigateTo} />

            {/* SECTOR 1: FEATURED CATEGORIES SECTION */}
            <section className="py-16 bg-[#050b15] border-b border-white/5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center space-y-3 max-w-xl mx-auto mb-12">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0071d1]/10 text-[#0071d1] text-xs font-bold uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5" />
                    {t.featuredCategories}
                  </div>
                  <h2 className="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
                    {lang === "fr" ? "CATÉGORIES PROFESSIONNELLES" : "تجهيزات احترافية متكاملة"}
                  </h2>
                  <p className="text-xs sm:text-sm text-white/50 leading-relaxed">
                    {lang === "fr" 
                      ? "Découvrez nos équipements haut de gamme sélectionnés spécifiquement pour maximiser vos performances sur le terrain."
                      : "اكتشف تشكيلاتنا الواسعة والممتازة المختارة خصيصاً لمساعدتك على التفوق في الملعب."}
                  </p>
                </div>

                {/* Categories Grid displays */}
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setSelectedCategory(cat.id);
                        navigateTo("#/products");
                      }}
                      className="group bg-[#0f172a] hover:bg-[#0071d1]/5 border border-white/5 hover:border-[#0071d1] rounded-2xl p-5 text-center transition-all duration-300 transform hover:-translate-y-1 cursor-pointer flex flex-col justify-between h-40 select-none shadow-xl"
                    >
                      <div className="w-11 h-11 rounded-xl bg-black/30 flex items-center justify-center text-[#0071d1] group-hover:bg-[#0071d1] group-hover:text-white transition-all mx-auto shadow-md">
                        <ShoppingBag className="w-5 h-5 mx-auto" />
                      </div>
                      <div>
                        <h3 className="text-xs sm:text-sm font-black text-white uppercase tracking-tight mt-3">
                          {cat.name[lang]}
                        </h3>
                        <span className="text-[10px] text-white/50 font-mono tracking-widest mt-1 block group-hover:text-[#ff510a] transition-colors uppercase">
                          EXPLORER
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </section>

            {/* SECTOR 2: BEST SELLERS */}
            <section className="py-16 bg-[#050b15]/80 border-b border-white/5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col sm:flex-row justify-between items-baseline gap-4 mb-10 select-none">
                  <div className="space-y-1.5 text-left">
                    <span className="text-xs font-mono font-bold text-[#ff510a] tracking-wider uppercase block">
                      {t.bestSellers}
                    </span>
                    <h2 className="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
                      {lang === "fr" ? "LES PLUS DEMANDÉS" : "المنتجات الأكثر مبيعاً"}
                    </h2>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedCategory("");
                      navigateTo("#/products");
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#0071d1] hover:text-white transition-colors cursor-pointer"
                  >
                    {lang === "fr" ? "Voir tout l'inventaire" : "عرض كل التشكيلة"}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {bestSellers.slice(0, 4).map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      lang={lang}
                      onNavigate={navigateTo}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* SECTOR 3: NEW ARRIVALS */}
            <section className="py-16 bg-[#050b15] border-b border-white/5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col sm:flex-row justify-between items-baseline gap-4 mb-10 select-none">
                  <div className="space-y-1.5 text-left">
                    <span className="text-xs font-mono font-bold text-[#0071d1] tracking-wider uppercase block">
                      {t.newArrivals}
                    </span>
                    <h2 className="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
                      {lang === "fr" ? "DERNIERS ARRIVAGES" : "آخر القطع والموديلات الواصلة"}
                    </h2>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedCategory("");
                      navigateTo("#/products");
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#ff510a] hover:text-white transition-colors cursor-pointer"
                  >
                    {lang === "fr" ? "Explorer tout" : "تصفح الكل"}
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {newArrivals.slice(0, 4).map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      lang={lang}
                      onNavigate={navigateTo}
                    />
                  ))}
                </div>
              </div>
            </section>

            {/* SECTOR 4: BRANDS */}
            <section className="py-14 bg-[#0f172a]/40 border-b border-white/5 select-none">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center max-w-xs mx-auto mb-8">
                  <span className="text-[10px] text-white/40 font-mono tracking-widest font-black uppercase">
                    PARTENAIRES DE RÉGIONS
                  </span>
                  <h3 className="text-sm font-black text-white/70 uppercase tracking-widest mt-1">
                    {lang === "fr" ? "MARQUES DISPONIBLES" : "العلامات التجارية المتاحة"}
                  </h3>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-6 justify-center items-center opacity-65 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
                  {BRANDS.map((br) => (
                    <button
                      key={br}
                      onClick={() => {
                        setSelectedBrand(br);
                        navigateTo("#/products");
                      }}
                      className="py-4 px-3 rounded-xl bg-[#050b15] border border-white/5 text-center font-mono font-black italic tracking-wide text-white hover:text-[#0071d1] hover:border-[#0071d1] transition-all cursor-pointer uppercase text-xs shadow-lg"
                    >
                      {br}
                    </button>
                  ))}
                </div>
              </div>
            </section>

            {/* SECTOR 5: WHY CHOOSE US */}
            <section className="py-20 bg-[#050b15] border-b border-white/5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center space-y-3 max-w-md mx-auto mb-16 select-none">
                  <h2 className="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
                    {t.whyUsTitle}
                  </h2>
                  <div className="w-16 h-1 bg-[#ff510a] mx-auto rounded-full"></div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/5 text-left space-y-4 shadow-xl">
                    <div className="w-12 h-12 rounded-xl bg-[#0071d1]/10 flex items-center justify-center text-[#0071d1]">
                      <Award className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-black text-white uppercase tracking-tight">
                      {t.whyUs1Title}
                    </h3>
                    <p className="text-xs sm:text-sm text-white/50 font-medium leading-relaxed">
                      {t.whyUs1Desc}
                    </p>
                  </div>

                  <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/5 text-left space-y-4 shadow-xl">
                    <div className="w-12 h-12 rounded-xl bg-[#ff510a]/10 flex items-center justify-center text-[#ff510a]">
                      <Truck className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-black text-white uppercase tracking-tight">
                      {t.whyUs2Title}
                    </h3>
                    <p className="text-xs sm:text-sm text-white/50 font-medium leading-relaxed">
                      {t.whyUs2Desc}
                    </p>
                  </div>

                  <div className="p-6 rounded-2xl bg-[#0f172a] border border-white/5 text-left space-y-4 shadow-xl">
                    <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500">
                      <MessageSquare className="w-6 h-6 fill-current" />
                    </div>
                    <h3 className="text-base font-black text-white uppercase tracking-tight">
                      {t.whyUs3Title}
                    </h3>
                    <p className="text-xs sm:text-sm text-white/50 font-medium leading-relaxed">
                      {t.whyUs3Desc}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* SECTOR 6: DELIVERY BAR */}
            <section className="py-12 bg-[#050b15] border-b border-white/5">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-r from-[#0f172a] to-[#050b15] border border-white/5 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden select-none shadow-2xl">
                  {/* Decorative faint glow */}
                  <div className="absolute top-0 right-0 w-48 h-48 bg-[#0071d1]/5 blur-2xl rounded-full pointer-events-none"></div>

                  <div className="flex items-center gap-4 text-left">
                    <div className="w-14 h-14 rounded-2xl bg-[#ff510a]/10 text-[#ff510a] flex items-center justify-center flex-shrink-0 shadow-lg shadow-orange-950/25">
                      <Truck className="w-7 h-7 animate-pulse" />
                    </div>
                    <div>
                      <h3 className="text-lg sm:text-xl font-black text-white uppercase tracking-tight">
                        {t.deliveryTitle} (58 Wilayas)
                      </h3>
                      <p className="text-xs sm:text-sm text-white/50 max-w-xl mt-1 leading-relaxed font-semibold">
                        {t.deliveryLocal}
                      </p>
                    </div>
                  </div>

                  <button
                    id="deliverycta-shop"
                    onClick={() => navigateTo("#/products")}
                    className="px-6 py-3.5 rounded-xl bg-[#0071d1] hover:bg-white hover:text-[#0071d1] text-white font-bold text-xs tracking-wider uppercase transition-all duration-300 transform hover:scale-105 flex-shrink-0 cursor-pointer"
                  >
                    {lang === "fr" ? "Commencer mes achats" : "ابدأ التسوق الآن"}
                  </button>
                </div>
              </div>
            </section>

            {/* SECTOR 7: WHATSAPP CALL TO ACTION */}
            <section className="py-16 bg-[#050b15] select-none">
              <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-6">
                <div className="w-16 h-16 rounded-3xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center mx-auto shadow-md">
                  <MessageSquare className="w-8 h-8 fill-current" />
                </div>
                <h2 className="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
                  {lang === "fr" ? "COMMANDE ET INFOS RAPIDES EN UN CLIC" : "طلب سريع واستفسار فوري بنقرة واحدة"}
                </h2>
                <p className="text-xs sm:text-sm text-white/50 leading-relaxed max-w-xl mx-auto font-semibold">
                  {lang === "fr" 
                    ? "Aucune inscription nécessaire, aucun numéro de carte bleue. Vous cliquez sur le produit pour générer le bon d'achat, et notre équipe valide tout directement sur WhatsApp."
                    : "لا تحتاج لإنشاء حساب أو وضع معلومات بطاقتك الائتمانية. اضغط على المنتج، وسيتم توليد كود الطلب لإرساله للفريق، لنقوم بتأكيد الشحن لك مباشرة."}
                </p>
                <div className="pt-2">
                  <a
                    href="https://wa.me/213540344572"
                    target="_blank"
                    id="home-whatsapp-cta-now"
                    className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-sm tracking-wide shadow-lg shadow-emerald-500/15 cursor-pointer max-w-md w-full sm:w-auto"
                  >
                    <MessageSquare className="w-5 h-5 fill-current" />
                    {lang === "fr" ? "Discuter avec nous" : "راسلنا الآن على الواتساب"}
                  </a>
                </div>
              </div>
            </section>
          </div>
        )}

        {/* VIEW 2: PRODUCTS CATALOG PAGE */}
        {activeHash === "#/products" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 animate-in fade-in duration-300">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Side: Advanced Filters Block */}
              <div className="lg:col-span-3">
                <Filters
                  lang={lang}
                  selectedCategory={selectedCategory}
                  setSelectedCategory={setSelectedCategory}
                  selectedSubcategory={selectedSubcategory}
                  setSelectedSubcategory={setSelectedSubcategory}
                  selectedBrand={selectedBrand}
                  setSelectedBrand={setSelectedBrand}
                  selectedSize={selectedSize}
                  setSelectedSize={setSelectedSize}
                  selectedColor={selectedColor}
                  setSelectedColor={setSelectedColor}
                  maxPrice={maxPrice}
                  setMaxPrice={setMaxPrice}
                  onClearFilters={handleClearFilters}
                />
              </div>

              {/* Right Side: Header and Grid Lists */}
              <div className="lg:col-span-9 space-y-6">
                
                {/* Catalog Head Banner details */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 p-5 rounded-2xl bg-[#0f172a] border border-white/5 select-none text-left shadow-xl">
                  <div>
                    <h1 className="font-sans text-xl sm:text-2xl font-black text-white uppercase tracking-tight">
                      {t.allProducts}
                    </h1>
                    <p className="text-xs text-white/50 mt-1 font-semibold">
                      {filteredProducts.length} {t.searchResult}
                    </p>
                  </div>
                  
                  {/* Quick indicator tags for current filters */}
                  {(selectedCategory || selectedBrand || selectedSize || selectedColor || searchQuery) && (
                    <button
                      id="btn-clear-filters-mini"
                      onClick={handleClearFilters}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-black/45 hover:bg-white/5 border border-white/5 hover:border-white/10 text-xs text-[#ff510a] font-black tracking-wider uppercase cursor-pointer transition-all"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      {lang === "fr" ? "Vider les filtres" : "إلغاء التصفية"}
                    </button>
                  )}
                </div>

                {/* Grid Lists */}
                {filteredProducts.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredProducts.map((product) => (
                      <ProductCard
                        key={product.id}
                        product={product}
                        lang={lang}
                        onNavigate={navigateTo}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="py-20 text-center space-y-4 rounded-3xl bg-[#0f172a]/45 border border-dashed border-white/10 max-w-lg mx-auto shadow-2xl">
                    <ShieldAlert className="w-12 h-12 text-[#ff510a] mx-auto animate-bounce" />
                    <h3 className="text-lg font-black text-white uppercase">
                      {t.noProducts}
                    </h3>
                    <p className="text-white/50 text-xs max-w-sm mx-auto leading-relaxed px-4 font-semibold">
                      {lang === "fr" 
                        ? "Essayez de réinitialiser vos paramètres ou d'élargir les critères de recherche pour trouver vos crampons ou maillots."
                        : "حاول تغيير خيارات التصفية أو تقليل السعر للبحث عن مقاسك أو موديلات الأحذية والقمصان المتاحة."}
                    </p>
                    <button
                      id="btn-retry-filters"
                      onClick={handleClearFilters}
                      className="px-5 py-2.5 rounded-xl bg-[#0071d1] hover:bg-white hover:text-[#0071d1] text-xs font-black uppercase tracking-wider transition-colors pointer-events-auto cursor-pointer shadow-md"
                    >
                      {lang === "fr" ? "Vider les filtres" : "إعادة الضبط والبدء من جديد"}
                    </button>
                  </div>
                )}

              </div>

            </div>
          </div>
        )}

        {/* VIEW 3: PRODUCT DETAILS PAGE */}
        {currentProduct && (
          <div className="animate-in fade-in duration-300">
            <ProductDetails
              product={currentProduct}
              lang={lang}
              onNavigate={navigateTo}
            />
          </div>
        )}

        {/* VIEW 4: ABOUT PAGE */}
        {activeHash === "#/about" && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-20 text-left space-y-8 animate-in fade-in duration-300">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0071d1]/10 text-[#0071d1] text-xs font-black uppercase tracking-wider">
                <Info className="w-4 h-4" />
                Foot Pro 27
              </div>
              <h1 className="font-sans text-3xl sm:text-5xl font-black text-white tracking-tight uppercase leading-none">
                {t.aboutHeading}
              </h1>
              <div className="w-20 h-1 bg-[#ff510a] rounded-full mt-2"></div>
            </div>

            <div className="bg-[#0f172a] border border-white/5 p-6 sm:p-10 rounded-3xl shadow-2xl space-y-6">
              <p className="text-sm sm:text-base text-white/90 leading-relaxed font-bold">
                {t.aboutIntro}
              </p>
              
              <p className="text-sm text-white/55 leading-relaxed font-semibold">
                {t.aboutDescription}
              </p>

              {/* Unique imported process showcase */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6 border-t border-white/10 select-none">
                <div className="p-4 bg-black/40 rounded-xl border border-white/5 space-y-2">
                  <h3 className="text-xs font-black text-[#0071d1] uppercase tracking-wider font-mono">
                    {lang === "fr" ? "🏬 Notre Boutique" : "🏬 عنواننا ومقرنا"}
                  </h3>
                  <p className="text-xs text-white/50 leading-relaxed font-semibold">
                    {lang === "fr" 
                      ? "Situé à Massra, Mostaganem (Algérie), notre magasin vous accueille pour essayer vos crampons sous les meilleurs conseils techniques."
                      : "يقع مقرنا بـ ماسرى، مستغانم (الجزائر). كابوس للاعبين ومحبي المستديرة، حيث نرحب بكم لتجربة واختيار مقاس أدق معداتكم الرياضية."}
                  </p>
                </div>
                <div className="p-4 bg-black/40 rounded-xl border border-white/5 space-y-2">
                  <h3 className="text-xs font-black text-[#ff510a] uppercase tracking-wider font-mono">
                    {lang === "fr" ? "✈️ Origine & Importation" : "✈️ جودة الاستيراد المباشر"}
                  </h3>
                  <p className="text-xs text-white/50 leading-relaxed font-semibold">
                    {lang === "fr" 
                      ? "Tous nos articles sont directement choisis et acheminés depuis nos plateaux d'approvisionnement en Europe pour garantir l'authentique original."
                      : "يتم استيراد كافة السلع والأحذية والقمصان ومعدات الحراس مباشرة عبر رحلات أسبوعية مخصصة من أسواق وموزعي أوروبا لتقديم الأصلي للمستطيل الأخضر."}
                  </p>
                </div>
              </div>
            </div>

            {/* Social Media & Contact Info */}
            <div className="bg-gradient-to-r from-[#0071d1]/10 to-[#ff510a]/5 border border-white/5 p-6 sm:p-10 rounded-3xl shadow-2xl space-y-6 animate-in fade-in duration-500">
              <div className="space-y-2">
                <h2 className="text-lg sm:text-xl font-black text-white uppercase tracking-wider">
                  {lang === "fr" ? "📱 REJOIGNEZ-NOUS SUR NOS RÉSEAUX" : "📱 تابعونا على وسائل التواصل الاجتماعي"}
                </h2>
                <p className="text-xs text-[#0071d1] leading-relaxed font-semibold uppercase font-mono tracking-widest">
                  {lang === "fr" 
                    ? "Restez connecté pour découvrir les nouveaux arrivages exclusifs"
                    : "ابقوا على تواصل لمعرفة آخر التشكيلات والموديلات فور وصولها"}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 select-none">
                {/* Facebook */}
                <a
                  href="https://www.facebook.com/share/1BUQCnUYic/?mibextid=wwXIfr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 rounded-xl bg-black/40 border border-white/5 hover:border-[#0071d1] hover:bg-[#0071d1]/5 transition-all duration-300 group cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-lg bg-blue-600/10 text-blue-500 flex items-center justify-center group-hover:scale-105 transition-transform">
                    <Facebook className="w-5 h-5 fill-current" />
                  </div>
                  <div className="text-left">
                    <span className="block text-[9px] text-white/40 font-bold uppercase tracking-wider">Facebook</span>
                    <span className="text-xs font-black text-white group-hover:text-[#0071d1] transition-colors leading-none tracking-tight">Foot Pro 27</span>
                  </div>
                </a>

                {/* Instagram */}
                <a
                  href="https://www.instagram.com/foot_pro27?igsh=Mnp5aThndG9hbWcw"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 rounded-xl bg-black/40 border border-white/5 hover:border-pink-500 hover:bg-pink-500/5 transition-all duration-300 group cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-lg bg-pink-500/10 text-pink-500 flex items-center justify-center group-hover:scale-105 transition-transform">
                    <Instagram className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <span className="block text-[9px] text-white/40 font-bold uppercase tracking-wider">Instagram</span>
                    <span className="text-xs font-black text-white group-hover:text-pink-500 transition-colors leading-none tracking-tight">@foot_pro27</span>
                  </div>
                </a>

                {/* TikTok */}
                <a
                  href="https://www.tiktok.com/@foot_pro_by_abdelatif?_r=1&_t=ZS-95pkZRFqkAq"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 rounded-xl bg-black/40 border border-white/5 hover:border-white hover:bg-white/5 transition-all duration-300 group cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-lg bg-white/10 text-white flex items-center justify-center group-hover:scale-105 transition-transform">
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                      <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.17-2.89-.6-4.09-1.51-.71-.53-1.3-1.22-1.77-1.97-.03 2.16.01 4.31-.01 6.47-.05 1.34-.33 2.76-.99 3.93-.68 1.25-1.78 2.3-3.1 2.87-1.45.65-3.13.78-4.67.43-1.61-.34-3.14-1.26-4.14-2.61-1.1-1.42-1.63-3.32-1.45-5.11.12-1.45.65-2.91 1.63-3.99 1.16-1.3 2.87-2.12 4.63-2.21v4.08c-.78.07-1.57.38-2.13.94-.52.52-.84 1.23-.91 1.97-.09.91.19 1.88.78 2.56.55.66 1.39 1.07 2.25 1.13.91.08 1.89-.15 2.59-.76.71-.62 1.05-1.62 1.01-2.56-.01-3.66-.01-7.32-.01-10.98.01-.01 0-.02 0-.03z" />
                    </svg>
                  </div>
                  <div className="text-left">
                    <span className="block text-[9px] text-white/40 font-bold uppercase tracking-wider">TikTok</span>
                    <span className="text-xs font-black text-white group-hover:text-white/80 transition-colors leading-none tracking-tight">Foot Pro</span>
                  </div>
                </a>

                {/* Email */}
                <a
                  href="mailto:Footpromostaganem@gmail.com"
                  className="flex items-center gap-3 p-4 rounded-xl bg-black/40 border border-white/5 hover:border-emerald-500 hover:bg-emerald-500/5 transition-all duration-300 group cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center group-hover:scale-105 transition-transform pointer-events-none">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div className="text-left truncate">
                    <span className="block text-[9px] text-white/40 font-bold uppercase tracking-wider">Email</span>
                    <span className="text-xs font-black text-white group-hover:text-emerald-500 transition-colors leading-none tracking-tight truncate font-mono">Footpromostaganem</span>
                  </div>
                </a>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 5: CONTACT PAGE */}
        {activeHash === "#/contact" && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 sm:py-20 text-left space-y-8 animate-in fade-in duration-300">
            <div className="space-y-3">
              <h1 className="font-sans text-3xl sm:text-5xl font-black text-white tracking-tight uppercase leading-none">
                {t.contactHeading}
              </h1>
              <div className="w-20 h-1 bg-[#ff510a] rounded-full mt-2"></div>
              <p className="text-sm text-neutral-400 leading-relaxed max-w-xl font-medium mt-1">
                {t.contactIntro}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
              {/* Info Block Left */}
              <div className="md:col-span-6 space-y-4 bg-[#0f172a] border border-white/5 p-6 rounded-2xl shadow-xl">
                <div className="space-y-4 select-none">
                  
                  {/* WhatsApp contact channel */}
                  <div className="flex gap-4 items-start pb-4 border-b border-white/10">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-500 flex items-center justify-center flex-shrink-0 shadow-md">
                      <MessageSquare className="w-5 h-5 fill-current" />
                    </div>
                    <div className="text-left">
                      <h3 className="text-xs font-black text-white uppercase tracking-wider">WhatsApp Orders</h3>
                      <p className="text-xs text-white/50 mt-1 font-mono hover:text-[#ff510a] transition-colors font-black">
                        <a href="https://wa.me/213540344572" target="_blank">+213 540 344 572</a>
                      </p>
                    </div>
                  </div>

                  {/* Phone channel */}
                  <div className="flex gap-4 items-start pb-4 border-b border-white/10">
                    <div className="w-10 h-10 rounded-xl bg-[#0071d1]/10 text-[#0071d1] flex items-center justify-center flex-shrink-0 shadow-md">
                      <Phone className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                      <h3 className="text-xs font-black text-white uppercase tracking-wider">{t.contactPhone}</h3>
                      <p className="text-xs text-white/50 mt-1 font-mono hover:text-[#ff510a] transition-colors font-black">
                        <a href="tel:+213540344572">+213 540 344 572</a>
                      </p>
                    </div>
                  </div>

                  {/* Physical Address channel */}
                  <div className="flex gap-4 items-start pb-4 border-b border-white/10">
                    <div className="w-10 h-10 rounded-xl bg-[#ff510a]/10 text-[#ff510a] flex items-center justify-center flex-shrink-0 shadow-md">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                      <h3 className="text-xs font-black text-white uppercase tracking-wider">{t.contactAddress}</h3>
                      <p className="text-xs text-white/50 mt-1 leading-relaxed font-bold">
                        {t.location}
                      </p>
                    </div>
                  </div>

                  {/* Horaires channel */}
                  <div className="flex gap-4 items-start">
                    <div className="w-10 h-10 rounded-xl bg-black/40 flex items-center justify-center flex-shrink-0 text-white/60 border border-white/5">
                      <Clock className="w-5 h-5" />
                    </div>
                    <div className="text-left">
                      <h3 className="text-xs font-black text-white uppercase tracking-wider">
                        {lang === "fr" ? "Heures d'ouverture" : "أوقات العمل في المحل"}
                      </h3>
                      <p className="text-xs text-white/50 mt-1 font-semibold">
                        {lang === "fr" 
                          ? "Samedi - Jeudi: 09:00 - 19:30" 
                          : "السبت - الخميس: 09:00 صباحاً - 07:30 مساءً"}
                      </p>
                      <p className="text-[10px] text-white/30 mt-0.5 font-bold">
                        {lang === "fr" ? "Fermé le Vendredi" : "الجمعة يوم عطلة"}
                      </p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Direct Maps Guide Right */}
              <div className="md:col-span-6 bg-[#0f172a] border border-white/5 p-6 rounded-2xl text-center space-y-4 shadow-xl">
                <div className="w-12 h-12 rounded-xl bg-[#ff510a]/10 text-[#ff510a] flex items-center justify-center mx-auto shadow-md select-none">
                  <MapPin className="w-6 h-6 animate-bounce" />
                </div>
                <h3 className="text-base font-black text-white uppercase tracking-tight">
                  {lang === "fr" ? "Trouver notre magasin" : "حدد موقعنا على الخريطة"}
                </h3>
                <p className="text-xs text-white/50 leading-relaxed max-w-xs mx-auto font-semibold">
                  {lang === "fr" 
                    ? "Notre local se situe sur l'axe central de Massra (Mostaganem, Algérie). Vous pouvez cliquer pour lancer l'application de navigation GPS."
                    : "يقع متجرنا على المحور والشارع الرئيسي في ماسرى (ولاية مستغانم، الجزائر). انقر لتشغيل نظام الملاحة GPS لتوجيهك."}
                </p>
                <div className="pt-2">
                  <a
                    href="https://maps.google.com/?q=Massra,Mostaganem,Algeria"
                    target="_blank"
                    id="btn-google-maps"
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-[#ff510a] hover:bg-white hover:text-neutral-950 font-black text-xs uppercase tracking-wider transition-colors cursor-pointer w-full text-white shadow-md shadow-orange-950/20"
                  >
                    Google Maps GPS
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 6: FAQ PAGE */}
        {activeHash === "#/faq" && (
          <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-20 text-left space-y-8 animate-in fade-in duration-300">
            <div className="space-y-3">
              <h1 className="font-sans text-3xl sm:text-5xl font-black text-white tracking-tight uppercase leading-none">
                {t.faqHeading}
              </h1>
              <div className="w-20 h-1 bg-[#ff510a] rounded-full mt-2"></div>
              <p className="text-sm text-white/50 font-semibold">
                {lang === "fr" 
                  ? "Des réponses simples à vos questions les plus fréquentes pour commander en toute sérénité."
                  : "إجابات بسيطة وشافية لأسئلتكم الشائعة لضمان طلبية سهلة ومريحة."}
              </p>
            </div>

            {/* Accordion List container */}
            <div className="space-y-4">
              {[
                { q: t.faq1Q, a: t.faq1A },
                { q: t.faq2Q, a: t.faq2A },
                { q: t.faq3Q, a: t.faq3A },
                { q: t.faq4Q, a: t.faq4A },
              ].map((faq, idx) => {
                const isOpen = faqOpenIdx === idx;
                return (
                  <div
                    key={idx}
                    className="bg-[#0f172a] border border-white/5 rounded-2xl overflow-hidden transition-all duration-300 hover:border-white/10 shadow-xl text-left"
                  >
                    <button
                      id={`faq-btn-${idx}`}
                      onClick={() => setFaqOpenIdx(isOpen ? null : idx)}
                      className="w-full px-5 py-4 flex justify-between items-center text-left hover:text-[#0071d1] transition-colors cursor-pointer select-none"
                    >
                      <span className="text-xs sm:text-sm font-black text-white uppercase">{faq.q}</span>
                      <ChevronDown
                        className={`w-4 h-4 text-[#ff510a] transition-transform duration-300 ${
                          isOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    
                    {isOpen && (
                      <div className="px-5 pb-5 pt-1.5 text-xs sm:text-sm text-white/50 border-t border-white/10 leading-relaxed font-semibold text-left">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* VIEW 7: PRIVACY POLICY PAGE */}
        {activeHash === "#/privacy" && (
          <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-20 text-left space-y-8 animate-in fade-in duration-300">
            <div className="space-y-3">
              <h1 className="font-sans text-3xl sm:text-5xl font-black text-white tracking-tight uppercase leading-none">
                {t.privacyHeading}
              </h1>
              <div className="w-20 h-1 bg-[#ff510a] rounded-full mt-2"></div>
            </div>

            <div className="bg-[#0f172a] border border-white/5 p-6 sm:p-8 rounded-3xl shadow-2xl">
              <p className="text-sm text-white/70 leading-relaxed font-semibold text-left">
                {t.privacyText}
              </p>
              
              <div className="pt-6 border-t border-white/10 mt-6 text-xs text-white/40 space-y-2 select-none text-left font-semibold">
                <span className="font-black text-white block uppercase font-mono tracking-widest text-[10px] mb-2">
                  CONTRAT DE FIABILITÉ
                </span>
                <p>• Aucune information de paiement bancaire formulée en ligne.</p>
                <p>• Archivage sécurisé et temporaire uniquement pour l'accompagnement de livraison.</p>
                <p>• Cryptage de bout-en-bout via le réseau sécurisé WhatsApp officiel.</p>
              </div>
            </div>
          </div>
        )}

        {/* VIEW 8: SPECIAL ADELATIF INTERACTIVE CMS STUDIO */}
        {activeHash === "#/admin" && (
          <div className="animate-in fade-in duration-300">
            <AdminDashboard
              lang={lang}
              productsList={productsList}
              setProductsList={(newList) => {
                setProductsList(newList);
                localStorage.setItem("footpro_products", JSON.stringify(newList));
              }}
            />
          </div>
        )}

      </main>

      {/* Persistent global WhatsApp Floating Trigger */}
      <WhatsAppFloating lang={lang} />

      {/* Modular site footer Component */}
      <Footer lang={lang} onNavigate={navigateTo} />
    </div>
  );
}
