import { createClient, SupabaseClient } from "@supabase/supabase-js";
import { Product } from "../data/products";

export interface SupabaseConfig {
  url: string;
  anonKey: string;
}

// Get config from Environment or Local Storage
export function getSupabaseConfig(): SupabaseConfig | null {
  const envUrl = (import.meta as any).env?.VITE_SUPABASE_URL;
  const envKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY;

  if (envUrl && envKey) {
    return { url: envUrl, anonKey: envKey };
  }

  const storedUrl = localStorage.getItem("footpro_supabase_url");
  const storedKey = localStorage.getItem("footpro_supabase_anon_key");

  if (storedUrl && storedKey) {
    return { url: storedUrl, anonKey: storedKey };
  }

  return null;
}

// Check configuration status
export function isSupabaseConfigured(): boolean {
  return getSupabaseConfig() !== null;
}

// Initialize Supabase Client
let cachedClient: SupabaseClient | null = null;

export function getSupabaseClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config) return null;

  // If credentials changed, update the client
  if (cachedClient && (cachedClient as any).supabaseUrl === config.url) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(config.url, config.anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      }
    });
    return cachedClient;
  } catch (error) {
    console.error("Failed to initialize Supabase client:", error);
    return null;
  }
}

// Save config to local storage
export function saveSupabaseConfig(url: string, anonKey: string): void {
  localStorage.setItem("footpro_supabase_url", url);
  localStorage.setItem("footpro_supabase_anon_key", anonKey);
  cachedClient = null; // Reset cache so next get compiles a new one
}

// Clear configuration
export function clearSupabaseConfig(): void {
  localStorage.removeItem("footpro_supabase_url");
  localStorage.removeItem("footpro_supabase_anon_key");
  cachedClient = null;
}

// Map database columns to front-end Product type
export function mapRowToProduct(row: any): Product {
  return {
    id: row.id,
    name: {
      fr: typeof row.name === "string" ? JSON.parse(row.name).fr : (row.name?.fr || ""),
      ar: typeof row.name === "string" ? JSON.parse(row.name).ar : (row.name?.ar || "")
    },
    category: row.category,
    subcategory: row.subcategory || "",
    price: Number(row.price),
    brand: row.brand,
    sizes: Array.isArray(row.sizes) ? row.sizes : (typeof row.sizes === "string" ? JSON.parse(row.sizes) : []),
    colors: {
      fr: Array.isArray(row.colors?.fr) ? row.colors.fr : (typeof row.colors === "string" ? JSON.parse(row.colors).fr : []),
      ar: Array.isArray(row.colors?.ar) ? row.colors.ar : (typeof row.colors === "string" ? JSON.parse(row.colors).ar : [])
    },
    image: row.image || "",
    description: {
      fr: typeof row.description === "string" ? JSON.parse(row.description).fr : (row.description?.fr || ""),
      ar: typeof row.description === "string" ? JSON.parse(row.description).ar : (row.description?.ar || "")
    },
    features: {
      fr: Array.isArray(row.features?.fr) ? row.features.fr : (typeof row.features === "string" ? JSON.parse(row.features).fr : []),
      ar: Array.isArray(row.features?.ar) ? row.features.ar : (typeof row.features === "string" ? JSON.parse(row.features).ar : [])
    },
    isNew: row.is_new ?? false,
    isBestSeller: row.is_best_seller ?? false
  };
}

// Map front-end Product type to database format
export function mapProductToRow(product: Product) {
  return {
    id: product.id,
    brand: product.brand,
    category: product.category,
    subcategory: product.subcategory,
    price: product.price,
    sizes: product.sizes,
    colors: { fr: product.colors.fr, ar: product.colors.ar },
    image: product.image,
    name: { fr: product.name.fr, ar: product.name.ar },
    description: { fr: product.description.fr, ar: product.description.ar },
    features: { fr: product.features.fr, ar: product.features.ar },
    is_new: product.isNew ?? false,
    is_best_seller: product.isBestSeller ?? false
  };
}

// Fetch products from database
export async function fetchProductsFromDb(): Promise<Product[] | null> {
  const supabase = getSupabaseClient();
  if (!supabase) return null;

  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .order("id");

    if (error) {
      console.error("Error fetching products from Supabase:", error);
      throw error;
    }

    if (data) {
      return data.map(mapRowToProduct);
    }
    return [];
  } catch (error) {
    console.error("Failed to query products table or connection:", error);
    return null;
  }
}

// Save or Update a single product
export async function saveProductToDb(product: Product): Promise<boolean> {
  const supabase = getSupabaseClient();
  if (!supabase) return false;

  const row = mapProductToRow(product);

  try {
    const { error } = await supabase
      .from("products")
      .upsert(row);

    if (error) {
      console.error("Error upserting product to Supabase:", error);
      return false;
    }
    return true;
  } catch (error) {
    console.error("Failed to upsert product:", error);
    return false;
  }
}

// Delete a single product
export async function deleteProductFromDb(productId: string): Promise<boolean> {
  const supabase = getSupabaseClient();
  if (!supabase) return false;

  try {
    const { error } = await supabase
      .from("products")
      .delete()
      .eq("id", productId);

    if (error) {
      console.error("Error deleting product from Supabase:", error);
      return false;
    }
    return true;
  } catch (error) {
    console.error("Failed to delete product:", error);
    return false;
  }
}

// Multi product batch synchronization
export async function batchSyncProducts(products: Product[]): Promise<{ success: boolean; count: number; error?: string }> {
  const supabase = getSupabaseClient();
  if (!supabase) return { success: false, count: 0, error: "Supabase client not initialized" };

  try {
    const rows = products.map(mapProductToRow);
    const { error } = await supabase
      .from("products")
      .upsert(rows);

    if (error) {
      console.error("Batch sync upsert error:", error);
      return { success: false, count: 0, error: error.message };
    }

    return { success: true, count: products.length };
  } catch (error: any) {
    console.error("Batch sync exception:", error);
    return { success: false, count: 0, error: error.message };
  }
}

// SQL Setup Query text generator for copying
export const SUPABASE_SQL_CREATION = `-- ÉTAPE PAR ÉTAPE : CRÉER VOTRE TABLE DE PRODUITS DANS SUPABASE
-- Allez dans votre Dashboard Supabase -> SQL Editor -> Coller ce code et cliquez sur RUN (Exécuter)

-- 1. Création de la table 'products'
CREATE TABLE IF NOT EXISTS public.products (
  id TEXT PRIMARY KEY,
  brand TEXT NOT NULL,
  category TEXT NOT NULL,
  subcategory TEXT,
  price NUMERIC NOT NULL,
  sizes JSONB NOT NULL DEFAULT '[]'::jsonb,
  colors JSONB NOT NULL DEFAULT '{"fr": [], "ar": []}'::jsonb,
  image TEXT,
  name JSONB NOT NULL DEFAULT '{"fr": "", "ar": ""}'::jsonb,
  description JSONB NOT NULL DEFAULT '{"fr": "", "ar": ""}'::jsonb,
  features JSONB NOT NULL DEFAULT '{"fr": [], "ar": []}'::jsonb,
  is_new BOOLEAN DEFAULT TRUE,
  is_best_seller BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- 2. Activer la sécurité au niveau des lignes (RLS)
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- 3. Politique 1 : Tout le monde peut voir les produits (Visiteurs rapides)
CREATE POLICY "Allow public read access" ON public.products
  FOR SELECT USING (true);

-- 4. Politique 2 : Seul l'administrateur connecté peut modifier la table
CREATE POLICY "Allow authenticated full write operations" ON public.products
  FOR ALL TO authenticated USING (true) WITH CHECK (true);

-- 5. Politique 3 : Politique fallback optionnelle (si vous n'utilisez pas Auth de suite)
-- CREATE POLICY "Allow edit for development" ON public.products FOR ALL USING (true);
`;
